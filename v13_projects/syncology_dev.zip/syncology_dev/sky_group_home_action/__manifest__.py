{
    'name': 'Role Home Action',
    'description': 'A Extend module Add fields for groups And Users',
    'version': '1.0',
    'author': 'Skyscend Business Solutions Pvt. Ltd.',
    'website': 'www.skyscendbs.com',
    'depends': ['base'],
    'data': [
        'views/res_groups_view.xml',

    ],
    'auto_install': False,
    'application': True
}
