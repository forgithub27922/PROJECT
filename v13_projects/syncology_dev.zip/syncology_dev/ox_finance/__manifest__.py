# -*- coding: utf-8 -*-
{
    'name' : 'Oxygen Finance VR. 13 2021,',
    'version' : '1.0',
    'summary': '',
    'sequence': 17,
    'author': 'Oxygen Business Technologies',
    'category': 'Accounts & Finance',
    'description': """
Oxygen Accounts customzied for Version 13, SEP 2021,,,
=====================================
 
    """,
    'website': '',
    'images' : [],
    'depends' : ['base_setup','account'],
    'data': ['security/ox_pos_security.xml',
	     'data/res_partner_mail.xml',
	     'data/mail_data.xml',
            #'security/ir.model.access.csv',
             'views/res_company_inh.xml',
	     'views/res_config_setting.xml',
#              'views/ox_fiscal_year.xml',
             'views/account_payment_view.xml',
             'views/account_account_view.xml',
             'views/partner_inherit_view.xml',
             'wizard/cash_bank_transaction_report_wizard.xml',
             'views/account_journal_inhrit_view.xml',
             'views/ox_finance_menu.xml',
             #removed for v13 'wizard/account_report_partner_ledger_inherited.xml',
             #removed for v 13'wizard/account_report_general_ledger_inherited.xml',
             
             'report/report_print_journal_entries.xml',
             'report/cash_bank_transactions_report.xml',
             'report/reports_declarator.xml',
             ],
    'demo': [
    ],
    'qweb': [#'static/src/xml/pos_ticket_view.xml',
             #'static/src/xml/pos_screen_image_view.xml'
],
    'images': [],
    'installable': True,
    'application': True,
    'auto_install': False,
}
