from odoo import api, fields, models,_
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning

class model_filter_records_runtime(models.TransientModel):
    _name = 'filter.records.runtime'
    _description = 'model_filter_records_runtimeddd'
    
    
    
    @api.model
    def filter_returned_producgts(self):
        _ids = []
        
        view_type = 'tree,form'
        
        sql1 = """select id from pos_order where id in(select order_id from pos_order_line where qty <0) """
        self.env.cr.execute(sql1)
        result = self.env.cr.fetchall()
        for order in result:
            _ids.append(order[0])  
        
         
        if len(_ids) >0:
            domain = "[('id', 'in', " + str(_ids) + ")]"
        else:
            domain = "[('id', '=',0)]"
        
        value = {
            'domain': domain,
            'name': _('Returned Orders'),
            'view_type': 'form',
            'view_mode': view_type,
            'res_model': 'pos.order',
            'view_id': False,
            'type': 'ir.actions.act_window'
        }
        
        return value



    