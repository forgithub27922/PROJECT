# -*- encoding: utf-8 -*-

from odoo import api, fields, models, _
import datetime
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning
import xlrd 
import base64

class posReturnProduct(models.TransientModel):
    
    _name = "pos.return.product"
    _description = "wizard.pos.prodcut.return"
    
    
    @api.onchange('process_type')
    def onchange_process_type(self):
        vals = {}
        vals['product_id'] = None
        vals['sale_qty'] = None
        vals['sale_qty_discount'] = None
        vals['price_subtotal'] = None
        vals['order_id'] = None
        return {'domain': {'order_id': None,'product_id':None},'value':vals}
    
    @api.onchange('order_id','product_id','general_product_id')
    def set_domain(self):
        """domain will be set if choirce is by prdocut, or domain will be set on prodcut if choice is on based on order """
        vals ={}
        vals['product_id'] = None
        vals['sale_qty'] = None
        vals['sale_qty_discount'] = None
        vals['price_subtotal'] = None
        if self.process_type == 'by_posorder':
            if self.order_id:
                if not self.product_id:
                    return {'domain': {'product_id': [('order_id', '=', self.order_id.id)]},'value':vals}
                else:
                    #last step when order is selected in first setep and product is selected in second step
                    vals['sale_qty'] = self.product_id.qty
                    vals['unit_price'] = self.product_id.price_unit
                    vals['sale_qty_discount'] = self.product_id.discount
                    vals['price_subtotal'] = self.product_id.price_subtotal
                    #auto fill return qty for ease of punching
                    vals['return_qty'] = self.product_id.qty
                    return {'value':vals}
        elif self.process_type == 'by_product':
            if self.general_product_id:
                if not self.order_id:
                    #Case 1: Process type os 'by product' but  order is still empty field
                    vals = {}
                    products = self.env['pos.order.line'].search([('product_id','=',self.general_product_id.id)])
                    products_list = []
                    for prd in products:
                        products_list.append(prd.order_id.id)
                    return {'domain': {'order_id': [('id', 'in',products_list)] },'value':vals}
                else:
                    #CASE2: Process type is by product, and also order is also selected
                    line = self.env['pos.order.line'].search([('product_id','=',self.general_product_id.id),('order_id','=',self.order_id.id)],limit=1) 
                    vals['sale_qty'] = line.qty
                    vals['product_id'] = line.id#because product id field is pointing to pos order line
                    vals['unit_price'] = line.price_unit
                    vals['sale_qty_discount'] = line.discount
                    vals['price_subtotal'] = line.price_subtotal
                    vals['return_qty'] = line.qty
                    return {'value':vals}
                
            else:
                return
                    
    @api.onchange('product_barcode')
    def onchange_barcode(self):
        vals ={}
        if self.product_barcode:
            if not self.order_id:
                raise UserError(_('Please Enter Order No'))
            product = self.env['product.template'].search([('barcode','=',self.product_barcode)])
            line = self.env['pos.order.line'].search([('product_id','=',product.id),('order_id','=',self.order_id.id)])
            if line:
                    vals['product_id'] = line.id
                    return {'value':vals}
            else:
                raise UserError(_('Seems that product does not belong to selected order.'))    
           
               
#     @api.onchange('product_id')
#     def onchange_product_id(self):
#         vals ={}
#         if self.process_type =='by_posorder':
#             if self.order_id:
#                 if self.product_id:
#                     
#                     vals['sale_qty'] = self.product_id.qty
#                     vals['unit_price'] = self.product_id.price_unit
#                     vals['sale_qty_discount'] = self.product_id.discount
#                     vals['price_subtotal'] = self.product_id.price_subtotal
#                 else:
#                     vals['product_id'] = None
#                     vals['sale_qty'] = None
#                     vals['sale_qty_discount'] = None
#                     
#         elif self.process_type == 'by_order':
#             
#         return {'value':vals}
    
    @api.onchange('return_qty')
    def onchange_return_qty(self):
        vals ={}
        if self.return_qty <= self.sale_qty:
            vals['returned_amount'] = self.return_qty * self.unit_price
        else:
            vals['return_qty'] = 0
        return {'value':vals}
    
    @api.model
    def ge_default_customer(self):
        
        rec = self.env['server.config'].search([],limit=1)
        return rec.default_customer_product_return.id
            
        
    order_id = fields.Many2one('pos.order', string = 'Order No', required=True)
    product_barcode = fields.Char('Product Barcode')
    product_id = fields.Many2one('pos.order.line', string = 'Product', required=True)
    general_product_id = fields.Many2one('product.product', string = 'Product.')
    customer = fields.Many2one('res.partner', domain = "[('customer','=',True)]",string = 'Customer.',default=ge_default_customer)
    sale_qty = fields.Integer('Sale Qty')
    sale_qty_discount = fields.Integer('Discount Given')
    unit_price = fields.Float('Unit Price')
    price_subtotal = fields.Float('Amount')
    return_qty = fields.Integer('Returned Qty',required=True)
    returned_amount = fields.Float('Amount to Return',required=True)
    process_type = fields.Selection([('by_posorder','By Purchase Order'),('by_product','By Product')],string = 'Process By',default='by_product')
    
    
    @api.multi
    def return_product(self):
        
        order_id = self.env['pos.order'].create({
                                                'name':         'Returned:'+str(self.order_id.name),
                                                'user_id':      self.env.user.id,
                                                'session_id':   self.order_id.session_id.id,
                                                'pos_reference': self.order_id.name+str("*"),
                                                'date_order':   datetime.date.today(),
                                                'state': 'draft',
                                                'partner_id':self.customer.id,
                                               })
       
        
        crate_lines =  self.env['pos.order.line'].create({
                                               'name':"Return for "+self.order_id.name, 
                                               'product_id':self.product_id.product_id.id,
                                               'price_unit':self.returned_amount,
                                               'qty':(self.return_qty*-1),
                                               'order_id':order_id.id,
                                               })
        value = {
            'name': _('Continue Product Return'),
            'context': {'form_view_initial_mode': 'edit', 'force_detailed_view': 'true'},#this will open the form in edit mode by default
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'pos.order',
            'res_id': order_id.id,
            'view_id': self.env.ref('point_of_sale.view_pos_pos_form').id,
            'type': 'ir.actions.act_window'
        }
#         view_id = self.env.ref('point_of_sale.view_pos_payment')
#         vals = {
#                 'amount'   : self.returned_amount
#             }
#         new = view_id.create(vals)
#         value = {
#             'name': _('Continue Product Return'),
#             #context': {'form_view_initial_mode': 'edit', 'force_detailed_view': 'true'},#this will open the form in edit mode by default
#             'view_type': 'form',
#             'view_mode': 'form',
#             'res_model': 'pos.make.payment',
#             'res_id': new.id,
#             'view_id': view_id.id,#self.env.ref('point_of_sale.view_pos_payment').id,
#             'type': 'ir.actions.act_window'
#         }
        return value
