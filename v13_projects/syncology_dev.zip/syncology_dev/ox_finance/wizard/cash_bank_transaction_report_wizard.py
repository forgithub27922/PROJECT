# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError
from datetime import datetime


class InternalExternalTransaction(models.TransientModel):
 
    _name = "internal.external.transaction.wizard"
    _description = "internal.external.transaction.wizard"
    
    date_from = fields.Date('Date From')
    date_to = fields.Date('Date To')
    journal_id = fields.Many2one('account.journal','Journal')
    options = fields.Selection([('all', 'All'),('internal_transfers_only', 'Internal Transfers Only'),('payments_only', 'Payments Only')],string = 'Options')

    @api.onchange('date_to')
    def onchange_date_range_compare(self):
        if self.date_to < self.date_from:
            raise UserError(_('Date to must be greater than date form'))

    def check_report(self):
        print("this is check report method")
        data = {}
        data['form'] = self.read([ 'date_from', 'date_to','journal_id','options'])[0]
        return self._print_report(data)

    def _print_report(self, data):
        data['form'].update(self.read([ 'date_from', 'date_to','journal_id','options'])[0])
        return self.env.ref('ox_finance.action_cash_bank_transaction_report_pdf').report_action(self, data=data, config=False)

