
import logging

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError
from odoo.modules.module import get_module_resource

_logger = logging.getLogger(__name__)

class Partner(models.Model):
    
    _name = 'res.partner'
    _inherit = 'res.partner'
    
    def create(self, vals):
        rec = super(Partner, self).create(vals)
        
        #email when new partner created
        ctx = {}
        email_list = ''
        if rec.customer_rank > 0:
            email_list = [user.email for user in self.env['res.users'].sudo().search(
            []) if user.has_group('oxygen_sales.group_notify_on_customer_creation')]
            ctx['partner_type'] = 'Customer'
        
        if rec.supplier_rank > 0:
            email_list = [user.email for user in self.env['res.users'].sudo().search(
            []) if user.has_group('oxygen_sales.group_notify_on_vendor_creation')]
            ctx['partner_type'] = 'Vendor'
        
        
        print("email list...",email_list)
        if email_list:
            ctx['partner_manager_email'] = ','.join(
                [email for email in email_list if email])
            ctx['email_from'] = self.env.user.email
            ctx['partner_name'] = self.env.user.name
            ctx['customer_name'] = rec.name
            ctx['lang'] = self.env.user.lang
            template = self.env.ref('ox_finance.partner_creation_mail_template')
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            db = self.env.cr.dbname
            ctx['action_url'] = "{}/web?db={}#id={}&view_type=form&model=res.partner".format(base_url, db, self.id)
            
            template.with_context(ctx).sudo().send_mail(rec.id, force_send=True, raise_exception=False)
        
        return rec
    
    def get_partner_balance(self):
        
        
        _ids = []
        if self.property_account_payable_id:
            _ids.append(self.property_account_payable_id.id)
        
        if self.property_account_receivable_id:
            _ids.append(self.property_account_receivable_id.id)
        
        query = """select COALESCE(sum(debit),'0') - COALESCE(sum(credit),'0') from account_move_line where partner_id= """+str(self.id)+"""
                   and account_id in("""+str(_ids)+""")  """
       
        self.env.cr.execute(query)
        amount = self.env.cr.fetchone()[0]
        self.partner_balance = amount
        
    def _get_line_ids(self):
        
        _ids = []
        if self.property_account_payable_id:
            _ids.append(self.property_account_payable_id.id)
        
        if self.property_account_receivable_id:
            _ids.append(self.property_account_receivable_id.id)

        lines = self.env['account.move.line'].search([('partner_id','=',self.id),('account_id','in',_ids)],order='date')
        self.moveline_entries = lines.ids
        
        total_debit = 0
        total_credit = 0
        
        #calculate partner final balance to show it on partner form
        for line in lines:
            total_debit = total_debit + line.debit
            total_credit = total_credit + line.credit
        balance = total_debit - total_credit
        self.partner_balance = balance
        return
    
    
   
    partner_balance = fields.Float(compute = '_get_line_ids',string = 'Partner Balance')
    moveline_entries = fields.One2many('account.move.line','partner_id',string = 'Entries',compute='_get_line_ids')
    #strn = fields.Float(string = 'STRN')


class Company(models.Model):
    
    _name = 'res.company'
    _inherit = 'res.company'
    
    strn = fields.Float(string = 'STRN')
