
import logging

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError
from odoo.modules.module import get_module_resource

_logger = logging.getLogger(__name__)


class account_payment(models.Model):
    
    _name = 'account.payment'
    _inherit = 'account.payment'
    
   
    cheq_no = fields.Char(string = 'Cheque No')
    cheq_date = fields.Date('Cheque Date') 
    state = fields.Selection(selection_add=[('to_approve', 'To Approve'), ('posted',)])
    approve_id = fields.Many2one('res.users', 'Approved By', readonly=True)

   
   
   
   
   
#     def return_student_paidfee_for_daterange(self,date_from,date_to):
#         """
#         This is the central method that returns  student paid fee in a specified date range desired by
#         the caller function. 
#         --input
#         1) date_from date_to
#         2)#Fixme how fee cateogry is nahndeled in this method
#         Last modified By Ibrahim on 3rd May-19 """
#         
#         
#         query = """select asd.name AS stdname,asd.registration_no,ap.payment_date,ap.amount,ap.name,ai.challan_number,ai.received_by 
#         from account_payment as ap inner join academic_student as asd 
#         on ap.partner_id = asd.partner_id inner join account_invoice as ai 
#         on asd.partner_id = ai.partner_id where ap.payment_date Between '""" +str(date_from) + """'AND'"""+str(date_to)+"""'AND ai.state = 'paid' """
#         self.env.cr.execute(query)
#         result = self.env.cr.dictfetchall()
#         return result
    
    def payment_approve_mail(self):
        ctx = {}
        email_list = [user.email for user in self.env['res.users'].sudo().search(
            []) if user.has_group('oxygen_finance.group_payment_amount')]
        if email_list:
            ctx['partner_manager_email'] = ','.join(
                [email for email in email_list if email])
            ctx['email_from'] = self.env.user.email
            ctx['partner_name'] = self.env.user.name
            ctx['customer_name'] = self.partner_id.name
            ctx['lang'] = self.env.user.lang
            ctx['partner_type'] = self.partner_type
            ctx['payment_type'] = dict(self._fields['payment_type'].selection).get(self.payment_type)
            template = self.env.ref('oxygen_finance.payment_workflow_template')
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            db = self.env.cr.dbname
            ctx['action_url'] = "{}/web?db={}#id={}&view_type=form&model=account.payment".format(base_url, db, self.id)
            
            if self.env.cr.dbname == 'dont_use' or self.env.cr.dbname == 'oxvor_production' or self.env.cr.dbname == 'inhouse_testing':
                template.with_context(ctx).sudo().send_mail(self.id, force_send=True, raise_exception=False)


    def action_validate_invoice_payment(self):
        company_id = self.env.user.company_id
        #if self.amount > company_id.payment_amount and company_id.payment_approval:
        if  self.amount > 0:
            self.write({'state': 'to_approve'})
            #set salesperson here
            self.payment_approve_mail()
        else:
            super(PaymentApproval, self).action_validate_invoice_payment()

    def confirm(self):
        company_id = self.env.user.company_id
        #if self.amount > company_id.payment_amount and company_id.payment_approval:
        if  self.amount > 0:
            self.write({'state': 'to_approve'})
            print("calling to get salesperson")
            self.compute_salesperson()
            self.payment_approve_mail()
        else:
            self.post()
            
        return        
        


    def approve(self):
        self.approve_id = self.env.user.id
        self.state = 'draft'
        self.post()
    
    @api.model
    def cash_bank_transfer_report_central_method(self,date_from,date_to,journal,options=False):
        """
        This is Main central method that returns payment transfers report,
        Created by Sohail 31-Jul-2021
        
        Called by
        1) cash bank transfer report 
        """
        transfers_result = self.env['account.payment'].search([('journal_id', '=', journal),('payment_date', '>=', date_from),('payment_date', '<=', date_to),('state', '=', 'posted')])
        
        search1_inbound = self.search([('journal_id', '=', journal),('payment_type', '=', 'inbound'),('payment_date', '>=', date_from),('payment_date', '<=', date_to),('state', '=', 'posted')])
        search2_transfer_in = self.search([('destination_journal_id', '=', journal),('payment_type', '=', 'transfer'),('payment_date', '>=', date_from),('payment_date', '<=', date_to),('state', '=', 'posted')])
        
        search3_outbound = self.search([('journal_id', '=', journal),('payment_type', '=', 'outbound'),('payment_date', '>=', date_from),('payment_date', '<=', date_to),('state', '=', 'posted')])
        search4_transfer_out = self.search([('journal_id', '=', journal),('payment_type', '=', 'transfer'),('payment_date', '>=', date_from),('payment_date', '<=', date_to),('state', '=', 'posted')])
        search5_expense_out = self.env['hr.expense.sheet'].search([('journal_id', '=', journal),('accounting_date', '>=', date_from),('accounting_date', '<=', date_to),('state', '=', 'done')])
        
        print("search5 expense Out --++--++ ",search5_expense_out)
        
        mydict = {'transfer_in': '','transfer_out':'','cash_received':'','cash_payment':'','expenses':'','total_receiving':'','total_payment':'','received_dict':'','payments_dict':''}
        result = []
        result2 = []
        result3 = []

        for s1 in search1_inbound:
            received_records = {'date':'','transfer_from':'','payment_type':'', 'rcd_amount':'', 'voucher_no':''}
            received_records['date'] = s1.payment_date
            received_records['transfer_from'] = s1.journal_id.name
            received_records['payment_type'] = s1.payment_type
            received_records['rcd_amount'] = s1.amount
            received_records['voucher_no'] = '--'
            result2.append(received_records)
        
        for s2 in search2_transfer_in:
            received_records = {'date':'','transfer_from':'','payment_type':'', 'rcd_amount':'', 'voucher_no':''}
            received_records['date'] = s2.payment_date
            received_records['transfer_from'] = s2.journal_id.name
            received_records['payment_type'] = s2.payment_type
            received_records['rcd_amount'] = s2.amount
            received_records['voucher_no'] = '--'
            result2.append(received_records)
        
        for s3 in search3_outbound:
            payment_records = {'date':'','paid_to':'','payment_type':'', 'pmt_amount':'', 'voucher_no':''}
            payment_records['date'] = s3.payment_date
            payment_records['paid_to'] = s3.journal_id.name
            payment_records['payment_type'] = s3.payment_type
            payment_records['pmt_amount'] = s3.amount
            payment_records['voucher_no'] = '--'
            result3.append(payment_records)
            
        for s4 in search4_transfer_out:
            payment_records = {'date':'','paid_to':'','payment_type':'', 'pmt_amount':'', 'voucher_no':''}
            payment_records['date'] = s4.payment_date
            payment_records['paid_to'] = s4.destination_journal_id.name
            payment_records['payment_type'] = s4.payment_type
            payment_records['pmt_amount'] = s4.amount
            payment_records['voucher_no'] = '--'
            result3.append(payment_records)
            
        for s5 in search5_expense_out:
            payment_records = {'date':'','paid_to':'','payment_type':'', 'pmt_amount':'', 'voucher_no':''}
            payment_records['date'] = s5.accounting_date
            payment_records['paid_to'] = s5.sheet_no
            payment_records['payment_type'] = 'Expense'
            payment_records['pmt_amount'] = s5.total_amount
            payment_records['voucher_no'] = '--'
            result3.append(payment_records)
                
        mydict['total_amount'] = '-'
        mydict['discount'] = '-'
        mydict['net_amount'] = '-'
        mydict['received_dict'] = result2
        mydict['payments_dict'] = result3
        result.append(mydict)
        print("this is main dict ====+ ",result)
        return result
        

    
    
    
    