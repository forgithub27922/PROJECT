
import logging

from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError, UserError
from odoo.modules.module import get_module_resource

_logger = logging.getLogger(__name__)


class Accountjournal(models.Model):
    
    _name = 'account.journal'
    _inherit = 'account.journal'
    
    #expense_ids = fields.One2many('hr.expense.sheet', 'journal_id', string='Expenses', readonly=True)
    #expense_count = fields.Integer(compute='_compute_expense_count', string='Expenses')
#     
#     def _compute_expense_count(self):
#         for exp in self:
#             exp.expense_count = len(exp.expense_ids)
#     
#     def act_journal_expense_list(self):
#         return {
#             'name': _('Expenses'),
#             'view_type': 'form',
#             'view_mode': 'tree,form',
#             'views': [(self.env.ref('hr_expense.view_hr_expense_sheet_tree').id,'tree'),(self.env.ref('hr_expense.view_hr_expense_sheet_form').id,'form')],
#             'res_model': 'hr.expense.sheet',
#             'type': 'ir.actions.act_window',
#             'target': 'Current',
#             'domain': "[('journal_id', '=', %s)]" % self.id,
#             'flags': {'form': {'action_buttons': True, 'options': {'mode': 'edit'}}},
#             'context'   :{}
#             }
    
    def get_moveline_entries(self):
        
        ids = self.env['account.move.line'].search([('account_id','=',4)])
        print("^^^^",ids.ids)
        return {
            'name': _('Journal Items'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'views': [(self.env.ref('ox_finance.view_move_line_tree_inh2').id,'tree'),(self.env.ref('account.view_move_line_form').id,'form')],
            'res_model': 'account.move.line',
            'type': 'ir.actions.act_window',
            'target': 'Current',
            'domain': "[('id', 'in', %s)]" % ids.ids,
            'flags': {'form': {'action_buttons': True, 'options': {'mode': 'edit'}}},
            'context': {'search_default_group_by_date': 1}
            }
    
    
    def action_record_new_expence(self):
        form_id = self.env.ref('oxygen_expense.hr_expense_simple_form_view', False)
        return {
        'name': 'New Expense',
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'hr.expense',
        'view_id'   : form_id.id,
        'type': 'ir.actions.act_window',
        'target': 'new',
        'context'   :{
                    'default_state':'draft',
                    'default_journal_id':self.id,
              }}
    
    def action_make_payment(self):
        form_id = self.env.ref('ox_finance.view_account_payment_form', False)
        return {
        'name': 'Make Payment',
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'account.payment',
        'view_id'   : form_id,
        'type': 'ir.actions.act_window',
        'target': 'new',
        'context'   :{
            'default_payment_type':'outbound',
            'default_journal_id':self.id,
              }}
    
    def action_receive_payment(self):
        form_id = self.env.ref('ox_finance.view_account_payment_form', False)
        return {
        'name': 'Receive Payment',
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'account.payment',
        'view_id'   : form_id,
        'type': 'ir.actions.act_window',
        'target': 'new',
        'context'   :{
            'default_payment_type':'inbound',
            'default_journal_id':self.id,
              }}
    
    def action_internal_transfer_in(self):
        form_id = self.env.ref('ox_finance.view_account_payment_form', False)
        return {
        'name': 'Internal Payment (In)',
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'account.payment',
        'view_id'   : form_id,
        'type': 'ir.actions.act_window',
        'target': 'new',
        'context'   :{
            'default_payment_type':'transfer',
            'default_journal_id': None,
            'default_destination_journal_id':self.id,
              }}
    
    def action_internal_transfer_out(self):
        form_id = self.env.ref('ox_finance.view_account_payment_form', False)
        return {
        'name': 'Internal Payment (Out)',
        'view_type': 'form',
        'view_mode': 'form',
        'res_model': 'account.payment',
        'view_id'   : form_id,
        'type': 'ir.actions.act_window',
        'target': 'new',
        'context'   :{
            'default_payment_type':'transfer',
            'default_journal_id':self.id,
              }}
        
    def call_journal_ledger_report(self):
        if self.default_debit_account_id:
            default_debit_account = self.default_debit_account_id.id
        else:
            raise UserError(_('Default debit account not set on journal'))
        return {
            'name': _('General Ledger'),
            'view_type': 'form',
            'view_mode': 'form',
            'view_id': self.env.ref('account.account_report_general_ledger_view').id,
            'res_model': 'account.report.general.ledger',
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context'   :{'default_account_ledger': default_debit_account,
                          'default_journal_ids': [self.id],
                          }}
    
    
   
   
