import logging
from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError, UserError
from odoo.modules.module import get_module_resource
# from odoo.tools.mail import reference_re
# from pygments.lexer import _inherit
from datetime import datetime,timedelta
import string
_logger = logging.getLogger(__name__)


class AccountGroup(models.Model):
    _name = "account.group"
    _description = 'Account Group'

class AccountAccount(models.Model):
    _name = "account.account"
    _inherit = "account.account"
    _description = "Account"
    
#     def get_current_debit_credit(self):
#          
#         query = """select COALESCE(sum(debit),'0') as debit,COALESCE(sum(credit),'0') as credit from account_move_line
#         inner join account_move on account_move.id = account_move_line.move_id
#          where 
#          account_move.state = 'posted' and 
#          account_move_line.account_id= """+str(self.id)
#         
#         self.env.cr.execute(query)
#         debit = self.env.cr.fetchone()[0]
#         credit = self.env.cr.fetchone()[1]
#         self.total_debit = debit
#         self.total_credit = credit
#         return
    
    @api.model
    def get_partner_balance_details(self, partner_ids, ignore_query):
        
        """This central method return partner balance details e.g. total debit, credit and balance amount with partner name
           we just need to pass customer or vendor id to method. Created by atif on 07 Nov 2019
           also this method can be called from any where...."""
           
        
        query = """select rp.name, sum(aml.debit) as debit, sum(aml.credit) as credit, sum(aml.debit)-sum(aml.credit) as balance 
                    from account_move as am
                    inner join account_move_line as aml on am.id=aml.move_id
                    inner join res_partner as rp on aml.partner_id=rp.id
                    where am.state='posted' and aml.partner_id in """ +str(partner_ids)+""" 
                    group by aml.partner_id,rp.name
                    """+str(ignore_query)+"""
                    order by rp.name"""
        
        self.env.cr.execute(query)
        result = self.env.cr.fetchall()
        return result
    
    
    def get_current_balance(self):
        query = """select COALESCE(sum(balance),'0'),COALESCE(sum(debit),'0') ,COALESCE(sum(credit),'0') from account_move_line
        inner join account_move on account_move.id = account_move_line.move_id
         where 
         account_move.state = 'posted' and 
         account_move_line.account_id= """+str(self.id)
        
        self.env.cr.execute(query)
        result = self.env.cr.fetchone()
        amount = result[0]
        debit = result[1]
        credit = result[2]
        self.ledger_balance = amount
        self.total_debit = debit
        self.total_credit = credit
        
    ledger_balance = fields.Float(compute = 'get_current_balance',string = 'Current Balance')
    total_debit = fields.Float(compute = 'get_current_balance',string = 'Debit')
    total_credit = fields.Float(compute = 'get_current_balance',string = 'Credit')
    moveline_entries = fields.One2many('account.move.line','account_id',string = 'Entries')
    
   



