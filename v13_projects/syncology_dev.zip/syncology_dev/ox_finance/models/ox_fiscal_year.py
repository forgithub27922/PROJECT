import logging
import calendar
from odoo import api, fields, models
from odoo import tools, _
from odoo.exceptions import ValidationError
from odoo.modules.module import get_module_resource
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta, MO
from datetime import datetime, timedelta, date
import calendar
from odoo.exceptions import AccessError, UserError, RedirectWarning, ValidationError, Warning
_logger = logging.getLogger(__name__)



class AccountFiscalyear(models.Model):
    _name = "account.fiscalyear"
    _description = "Fiscal Year"
   

    @api.model
    def get_runing_fiscalyear_id(self):
        #Fixme
        fiscal_id = self.env['account.fiscalyear'].search([])[0]
        form_id = self.env.ref('ox_finance.view_account_fiscalyear_form', False)
        return {
            'name': 'Running Fiscal Year',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'account.fiscalyear',
            'view_id'   : form_id.id,
            'type': 'ir.actions.act_window',
            'target'    : 'current',
            'res_id':fiscal_id.id,
            'context'   :{
                          }}

    name =  fields.Char(compute='_get_name_code', string='Fiscal Year')
    code = fields.Char(compute='_get_name_code', string='Code')
    company_id =  fields.Many2one('res.company', 'Company', required=True)
    date_start =  fields.Date('Start Date', required=True)
    date_stop =  fields.Date('End Date', required=True)
    period_ids =  fields.One2many('account.period', 'fiscalyear_id', 'Periods')
    state =  fields.Selection([('draft','Open'), ('done','Closed')], 'Status',default = 'draft' ,readonly=True, copy=False)
    end_journal_period_id =  fields.Many2one('account.journal.period', 'End of Year Entries Journal',readonly=True, copy=False)

    def _get_name_code(self):
            st = datetime.strptime(self.date_start, '%Y-%m-%d')
            et = datetime.strptime(self.date_stop, '%Y-%m-%d')
            self.name = st.strftime('%Y-') + et.strftime('-%Y')[-2:]
            self.code = st.strftime('%Y-')[2:] + et.strftime('%Y')[-2:]
            
    
    @api.onchange('date_stop')
    def onchange_fiscal_year_date_comparison(self):
        if self.date_stop < self.date_start:
            raise UserError(_('End date must be greater than start date'))
    
    

#         'company_id': lambda self,cr,uid,c: self.pool.get('res.users').browse(cr, uid, uid, c).company_id.id,
#     }
#     _order = "date_start, id"

#     @api.constrains('age')
#     def _check_duration(self, cr, uid, ids, context=None):
#         obj_fy = self.browse(cr, uid, ids[0], context=context)
#         if obj_fy.date_stop < obj_fy.date_start:
#             return False
#         return True

#     _constraints = [
#         (_check_duration, 'Error!\nThe start date of a fiscal year must precede its end date.', ['date_start','date_stop'])
#     ]

#     def create_period3(self, cr, uid, ids, context=None):
#         return self.create_period(cr, uid, ids, context, 3)
   
   
   
   
    
    
    
    def create_period(self):
        print("This is the create period method11")
        period_obj = self.env['account.period']
        ds = datetime.strptime(self.date_start, '%Y-%m-%d')
#         period_obj.create({
#                 'name':  "%s %s" % (_('Opening Period'), ds.strftime('%Y')),
#                 'code': ds.strftime('00/%Y'),
#                 'date_start': ds,
#                 'date_stop': ds,
#                 'special': True,
#                 'fiscalyear_id': self.id,
#             })
#         print("This is the create period method22", ds.strftime('%Y-%m-%d'))
        
        month_exsists = self.env['account.period'].search([('fiscalyear_id', '=', self.id)]) 
        if not month_exsists:
            while ds.strftime('%Y-%m-%d') <= self.date_stop:
              
                de = ds + relativedelta(months=1, days=-1)
                word_month=ds.strftime('%b').upper()
                if de.strftime('%Y-%m-%d') > self.date_stop:
                    de = datetime.strptime(self.date_stop, '%Y-%m-%d')
                   
                period_obj.create({
                   'name': word_month + ds.strftime('-%Y'),
                   'code': ds.strftime('%m/%Y'),
                   'date_start': ds.strftime('%Y-%m-%d'),
                   'date_stop': de.strftime('%Y-%m-%d'),
                   'fiscalyear_id': self.id,
               })
                ds = ds + relativedelta(months=1)
        return True
        
#     def find(self, cr, uid, dt=None, exception=True, context=None):
#         res = self.finds(cr, uid, dt, exception, context=context)
#         return res and res[0] or False
# 
#     def finds(self, cr, uid, dt=None, exception=True, context=None):
#         if context is None: context = {}
#         if not dt:
#             dt = fields.date.context_today(self,cr,uid,context=context)
#         args = [('date_start', '<=' ,dt), ('date_stop', '>=', dt)]
#         if context.get('company_id', False):
#             company_id = context['company_id']
#         else:
#             company_id = self.pool.get('res.users').browse(cr, uid, uid, context=context).company_id.id
#         args.append(('company_id', '=', company_id))
#         ids = self.search(cr, uid, args, context=context)
#         if not ids:
#             if exception:
#                 model, action_id = self.pool['ir.model.data'].get_object_reference(cr, uid, 'account', 'action_account_fiscalyear')
#                 msg = _('There is no period defined for this date: %s.\nPlease go to Configuration/Periods and configure a fiscal year.') % dt
#                 raise openerp.exceptions.RedirectWarning(msg, action_id, _('Go to the configuration panel'))
#             else:
#                 return []
#         return ids

#     def name_search(self, cr, user, name, args=None, operator='ilike', context=None, limit=80):
#         if args is None:
#             args = []
#         if operator in expression.NEGATIVE_TERM_OPERATORS:
#             domain = [('code', operator, name), ('name', operator, name)]
#         else:
#             domain = ['|', ('code', operator, name), ('name', operator, name)]
#         ids = self.search(cr, user, expression.AND([domain, args]), limit=limit, context=context)
#         return self.name_get(cr, user, ids, context=context)


class AccountPeriod(models.Model):
    _name = "account.period"
    _description = "Account period"
    _order = 'date_start desc'
    
    def get_period_id_form_month(self,month_id,year):
        arr = calendar.monthrange(year,month_id)
        end_date = str(year)+"-"+str(month_id)+"-"+str(arr[1])
        period_id = self.search([('date_stop','=',end_date)])
        if not period_id:
            raise UserError(_('Seems like Fiscal Year Or its Periods not defined for '+str(month_id)+'-'+str(year)+'. Make sure that a Fiscal Year is defined along with its monthly periods.'))
        else:
            return period_id

    def check_period_status(self):
        today = date.today()
        
        
        if str(today) > self.date_stop:
            self.state = 'Closed'
        elif str(today) < self.date_start:    
            self.state = 'draft'
        elif str(today) >= self.date_start and str(today) <= self.date_start:
            self.state = 'Open'
        return
    
    
    name = fields.Char('Period Name', required=True)
    code =  fields.Char('Code', size=12)
    special =  fields.Boolean('Opening/Closing Period',help="These periods can overlap.")
    date_start =  fields.Date('Start of Period', required=True, states={'done':[('readonly',True)]})
    date_stop =  fields.Date('End of Period', required=True, states={'done':[('readonly',True)]})
    fiscalyear_id =  fields.Many2one('account.fiscalyear', 'Fiscal Year', required=True)
    state =  fields.Selection([('draft','Draft'), ('Open','Open'),('Closed','Closed')],compute = 'check_period_status',string= 'Status',default = 'draft', readonly=True, copy=False,help='When monthly periods are created. The status is \'Draft\'. At the end of monthly period it is in \'Done\' status.')
    company_id =  fields.Many2one('res.company',related='fiscalyear_id.company_id', string='Company', store=True, readonly=True)
    is_updated = fields.Boolean('Month Updated')
    

#     _order = "date_start, special desc"
#     _sql_constraints = [
#         ('name_company_uniq', 'unique(name, company_id)', 'The name of the period must be unique per Company!'),
#     ]

#     def _check_duration(self,cr,uid,ids,context=None):
#         obj_period = self.browse(cr, uid, ids[0], context=context)
#         if obj_period.date_stop < obj_period.date_start:
#             return False
#         return True

#     def _check_year_limit(self,cr,uid,ids,context=None):
#         for obj_period in self.browse(cr, uid, ids, context=context):
#             if obj_period.special:
#                 continue
# 
#             if obj_period.fiscalyear_id.date_stop < obj_period.date_stop or \
#                obj_period.fiscalyear_id.date_stop < obj_period.date_start or \
#                obj_period.fiscalyear_id.date_start > obj_period.date_start or \
#                obj_period.fiscalyear_id.date_start > obj_period.date_stop:
#                 return False
# 
#             pids = self.search(cr, uid, [('date_stop','>=',obj_period.date_start),('date_start','<=',obj_period.date_stop),('special','=',False),('id','<>',obj_period.id)])
#             for period in self.browse(cr, uid, pids):
#                 if period.fiscalyear_id.company_id.id==obj_period.fiscalyear_id.company_id.id:
#                     return False
#         return True

#     _constraints = [
#         (_check_duration, 'Error!\nThe duration of the Period(s) is/are invalid.', ['date_stop']),
#         (_check_year_limit, 'Error!\nThe period is invalid. Either some periods are overlapping or the period\'s dates are not matching the scope of the fiscal year.', ['date_stop'])
#     ]

#     @api.returns('self')
#     def next(self, cr, uid, period, step, context=None):
#         ids = self.search(cr, uid, [('date_start','>',period.date_start)])
#         if len(ids)>=step:
#             return ids[step-1]
#         return False

#     @api.returns('self')
#     def find(self, cr, uid, dt=None, context=None):
#         if context is None: context = {}
#         if not dt:
#             dt = fields.date.context_today(self, cr, uid, context=context)
#         args = [('date_start', '<=' ,dt), ('date_stop', '>=', dt)]
#         if context.get('company_id', False):
#             args.append(('company_id', '=', context['company_id']))
#         else:
#             company_id = self.pool.get('res.users').browse(cr, uid, uid, context=context).company_id.id
#             args.append(('company_id', '=', company_id))
#         result = []
#         if context.get('account_period_prefer_normal', True):
#             # look for non-special periods first, and fallback to all if no result is found
#             result = self.search(cr, uid, args + [('special', '=', False)], context=context)
#         if not result:
#             result = self.search(cr, uid, args, context=context)
#         if not result:
#             model, action_id = self.pool['ir.model.data'].get_object_reference(cr, uid, 'account', 'action_account_period')
#             msg = _('There is no period defined for this date: %s.\nPlease go to Configuration/Periods.') % dt
#             raise openerp.exceptions.RedirectWarning(msg, action_id, _('Go to the configuration panel'))
#         return result

#     def action_draft(self, cr, uid, ids, context=None):
#         mode = 'draft'
#         for period in self.browse(cr, uid, ids):
#             if period.fiscalyear_id.state == 'done':
#                 raise osv.except_osv(_('Warning!'), _('You can not re-open a period which belongs to closed fiscal year'))
#         cr.execute('update account_journal_period set state=%s where period_id in %s', (mode, tuple(ids),))
#         cr.execute('update account_period set state=%s where id in %s', (mode, tuple(ids),))
#         self.invalidate_cache(cr, uid, context=context)
#         return True

#     def name_search(self, cr, user, name, args=None, operator='ilike', context=None, limit=100):
#         if args is None:
#             args = []
#         if operator in expression.NEGATIVE_TERM_OPERATORS:
#             domain = [('code', operator, name), ('name', operator, name)]
#         else:
#             domain = ['|', ('code', operator, name), ('name', operator, name)]
#         ids = self.search(cr, user, expression.AND([domain, args]), limit=limit, context=context)
#         return self.name_get(cr, user, ids, context=context)
# 
#     def write(self, cr, uid, ids, vals, context=None):
#         if 'company_id' in vals:
#             move_lines = self.pool.get('account.move.line').search(cr, uid, [('period_id', 'in', ids)])
#             if move_lines:
#                 raise osv.except_osv(_('Warning!'), _('This journal already contains items for this period, therefore you cannot modify its Company field.'))
#         return super(account_period, self).write(cr, uid, ids, vals, context=context)

#     def build_ctx_periods(self, cr, uid, period_from_id, period_to_id):
#         if period_from_id == period_to_id:
#             return [period_from_id]
#         period_from = self.browse(cr, uid, period_from_id)
#         period_date_start = period_from.date_start
#         company1_id = period_from.company_id.id
#         period_to = self.browse(cr, uid, period_to_id)
#         period_date_stop = period_to.date_stop
#         company2_id = period_to.company_id.id
#         if company1_id != company2_id:
#             raise osv.except_osv(_('Error!'), _('You should choose the periods that belong to the same Company.'))
#         if period_date_start > period_date_stop:
#             raise osv.except_osv(_('Error!'), _('Start period should precede then end period.'))
# 
#         # /!\ We do not include a criterion on the company_id field below, to allow producing consolidated reports
#         # on multiple companies. It will only work when start/end periods are selected and no fiscal year is chosen.
# 
#         #for period from = january, we want to exclude the opening period (but it has same date_from, so we have to check if period_from is special or not to include that clause or not in the search).
#         if period_from.special:
#             return self.search(cr, uid, [('date_start', '>=', period_date_start), ('date_stop', '<=', period_date_stop)])
#         return self.search(cr, uid, [('date_start', '>=', period_date_start), ('date_stop', '<=', period_date_stop), ('special', '=', False)])


class AccountJournalPeriod(models.Model):
    _name = "account.journal.period"
    _description = "Journal Period"

    
    def _icon_get(self):
        result = {}.fromkeys(self.ids, 'STOCK_NEW')
        for r in self.read(self.ids, ['state']):
            result[r['id']] = {
                'draft': 'STOCK_NEW',
                'printed': 'STOCK_PRINT_PREVIEW',
                'done': 'STOCK_DIALOG_AUTHENTICATION',
            }.get(r['state'], 'STOCK_NEW')
        return result

    name =  fields.Char('Journal-Period Name', required=True)
    journal_id =  fields.Many2one('account.journal', 'Journal', required=True, ondelete="cascade")
    period_id = fields.Many2one('account.period', 'Period', required=True, ondelete="cascade")
    icon =  fields.Char('Icon',compute='_icon_get')
    active =  fields.Boolean('Active', help="If the active field is set to False, it will allow you to hide the journal period without removing it.")
    state =  fields.Selection([('draft','Draft'), ('printed','Printed'), ('done','Done')], 'Status', required=True, readonly=True, help='When journal period is created. The status is \'Draft\'. If a report is printed it comes to \'Printed\' status. When all transactions are done, it comes in \'Done\' status.')
    fiscalyear_id =  fields.Many2one('account.fiscalyear',related='period_id.fiscalyear_id', string='Fiscal Year', store=True, readonly=True)
    company_id =  fields.Many2one('res.company',related='journal_id.company_id', string='Company', store=True, readonly=True)
    






#     def _check(self, cr, uid, ids, context=None):
#         for obj in self.browse(cr, uid, ids, context=context):
#             cr.execute('select * from account_move_line where journal_id=%s and period_id=%s limit 1', (obj.journal_id.id, obj.period_id.id))
#             res = cr.fetchall()
#             if res:
#                 raise osv.except_osv(_('Error!'), _('You cannot modify/delete a journal with entries for this period.'))
#         return True
# 
#     def write(self, cr, uid, ids, vals, context=None):
#         self._check(cr, uid, ids, context=context)
#         return super(account_journal_period, self).write(cr, uid, ids, vals, context=context)
# 
#     def create(self, cr, uid, vals, context=None):
#         period_id = vals.get('period_id',False)
#         if period_id:
#             period = self.pool.get('account.period').browse(cr, uid, period_id, context=context)
#             vals['state']=period.state
#         return super(account_journal_period, self).create(cr, uid, vals, context)
# 
#     def unlink(self, cr, uid, ids, context=None):
#         self._check(cr, uid, ids, context=context)
#         return super(account_journal_period, self).unlink(cr, uid, ids, context=context)

#     _defaults = {
#         'state': 'draft',
#         'active': True,
#     }
#     _order = "period_id"
