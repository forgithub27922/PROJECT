# -*- coding: utf-8 -*-
from odoo import models, fields

class PaymentWorkFlow(models.TransientModel):
    _inherit = 'res.config.settings'

    payment_approval = fields.Boolean("Payment Approval")
    payment_amount = fields.Float(string="Payment Amount")
