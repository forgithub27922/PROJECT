# -*- coding: utf-8 -*-

from . import account_payment
from . import partner_inherit
from . import ox_fiscal_year
from . import account_account
from . import account_journal_inherit
from . import res_config_setting
