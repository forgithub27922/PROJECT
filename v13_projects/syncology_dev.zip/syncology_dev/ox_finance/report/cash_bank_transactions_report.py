# -*- coding: utf-8 -*-

import time
from odoo import api, models
from dateutil.parser import parse
from odoo.exceptions import UserError
from datetime import datetime
from odoo import api, fields, models, _

        
class TransactionReport(models.AbstractModel):
    _name = 'report.ox_finance.cash_bank_transaction_report_templet'
    
    @api.model
    def _get_report_values(self, docids, data=None):
        result = None
        self.model = self.env.context.get('active_model')
        rec = self.env[self.model].browse(self.env.context.get('active_id'))
        print("rec is ====== ",rec)
        form = data['form']
        journal = rec.id
        date_from = form['date_from']
        date_to = form['date_to']
        options = form['options']
        
        result = self.env['account.payment'].cash_bank_transfer_report_central_method(date_from,date_to,journal,options) 
        print("transfer result",result)
       
        return {
            'doc_ids': self.ids,
            'doc_model': 'ox_finance.account.journal',
            'docs': result,
            'rec': rec,
            'date_from':date_from,
            'date_to':date_to,
#             'reg_no': rec.student_id.registration_no,
#             'student_id': form['student_id'],
            #'get_attendances_recordes':self._get_attendace_records,
            #'get_remaining_leaves':self._get_remaining_casual_leaves,
        }
        