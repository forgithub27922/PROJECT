# -*- coding: utf-8 -*-

from . import ir_ui_view
from . import res_config
