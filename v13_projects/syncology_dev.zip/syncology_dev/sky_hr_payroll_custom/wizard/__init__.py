from . import hr_addition_reject_wizard
from . import hr_salary_report_wizard
