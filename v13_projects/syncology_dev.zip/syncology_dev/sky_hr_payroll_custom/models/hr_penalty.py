# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#    Copyright (C) 2020 Skyscend Business Solutions Pvt. Ltd.(http://www.skyscendbs.com)
#
##############################################################################
from odoo import models, fields, api, _
from odoo.exceptions import UserError


class PenaltyType(models.Model):
    _name = 'hr.penalty.type'
    _description = 'Penalty Types'
    _rec_name = 'name'

    name = fields.Char('Name')
    code = fields.Char('Code')
    penalty_entries = fields.One2many('hr.penalty.entries', 'penalty_type_id', 'Penalty Entries')


class Penalty(models.Model):
    _name = 'hr.penalty'
    _description = 'Penalties'
    _rec_name = 'reason'

    employee_id = fields.Many2one('hr.employee', 'Employee')
    penalty_type_id = fields.Many2one('hr.penalty.type', 'Penalty Type')
    value_type = fields.Selection([('pay_cut', 'Pay Cut'), ('hours','Hours'), ('days', 'Days'), ('minutes', 'Minutes')], 'Value Type')
    value = fields.Float('Value')
    issued_by = fields.Many2one('res.users', string='Issued By', default=lambda self: self.env.user.id)
    reason = fields.Char('Reason')
    date = fields.Date('Date', default=fields.Date.today())
    state = fields.Selection([('pending', 'Pending'),
                              ('approved', 'Approved'),
                              ('rejected', 'Rejected')], 'State', default='pending')
    employee_salary_id = fields.Many2one('hr.employee.salary', 'Employee Salary')
    tracking_line_id = fields.Many2one('time.tracking.line', 'Tracking Line')
    amount = fields.Float('Penalty Amount')
    lock = fields.Boolean('Lock')

    @api.onchange('value', 'value_type', 'employee_id', 'date')
    def onchange_value_type(self):
        """
        This method will update the penalty amount
        ------------------------------------------
        @param self: object pointer
        :return:
        """
        for pen in self:
            worked_hours = pen.employee_id.count_working_hours(employee_id=pen.employee_id, date=pen.date)
            if pen.value_type == 'pay_cut':
                pen.amount = pen.value
            elif pen.value_type == 'hours':
                pen.amount = pen.employee_id.hourly_rate * pen.value
            elif pen.value_type == 'days':
                pen.amount = pen.employee_id.hourly_rate * pen.value * worked_hours

    def penalty_pending(self):
        for penalty in self:
            if penalty.lock == True:
                raise UserError(_("You can not reset approved Penalties!"))
            penalty.state = 'pending'

    def penalty_approved(self):
        tracking_line = self.env['time.tracking.line'].sudo().search([('employee_id', '=', self.employee_id.id),
                                                               ('date', '=', self.date)], limit=1)
        for penalty in self:
            if tracking_line:
                penalty.write({'tracking_line_id': tracking_line.id})
            penalty.state = 'approved'

    def penalty_rejected(self):
        for penalty in self:
            penalty.state = 'rejected'

    def unlink(self):
        """
        Overridden the unlink method to restrict deletion of approved penalties
        -----------------------------------------------------------------------
        @param self: object pointer
        :return True
        """
        for penalty in self:
            if penalty.state != 'pending' or penalty.lock == True:
                raise UserError(_("You can not delete approved Penalties!"))
        return super(Penalty, self).unlink()


class PenaltyEntries(models.Model):
    _name = 'hr.penalty.entries'
    _description = 'Penalty Entries'
    _rec_name = 'penalty_type_id'

    penalty_type_id = fields.Many2one('hr.penalty.type', 'Penalty Type')
    actual_time = fields.Float('Actual Time')
    actual_time_unit = fields.Selection([('minutes', 'Minutes'), ('hours','Hours'), ('days', 'Days')], 'Actual Time Unit')
    calculated_time = fields.Float('Calculated Time')
    calculated_time_unit = fields.Selection([('minutes', 'Minutes'), ('hours', 'Hours'), ('days', 'Days')],
                                        'Calculated Time Unit')
