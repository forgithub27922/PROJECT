# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#
##############################################################################
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError


class AdditionType(models.Model):
    _name = 'hr.addition.type'
    _description = 'Hr Addition Type'
    _rec_name = 'name'

    name = fields.Char('Name')
    code = fields.Char('Code')


class Addition(models.Model):
    _name = 'hr.addition'
    _description = 'Hr Addition'
    _rec_name = 'reason'

    employee_id = fields.Many2one('hr.employee', 'Employee')
    addition_type_id = fields.Many2one('hr.addition.type', 'Addition Type')
    type_of_value = fields.Selection([('money', 'Money'),
                                      ('days', 'Days'),
                                      ('hours', 'Hours')], 'Type of value')
    value = fields.Float('Value')
    value_amount = fields.Float(related="value", string='Value')
    issued_by = fields.Many2one('res.users', 'Issued By', default=lambda self: self.env.uid)
    reason = fields.Char('Reason')
    rejection_reason = fields.Char('Rejection Reason')
    date = fields.Date('Date', default=fields.Date.today())
    state = fields.Selection([('pending', 'Pending'),
                              ('approved', 'Approved'),
                              ('rejected', 'Rejected')], 'Status', default='pending')
    employee_salary_id = fields.Many2one('hr.employee.salary', 'Employee Salary')
    tracking_line_id = fields.Many2one('time.tracking.line', 'Tracking Line')
    amount = fields.Float('Amount')
    is_overtime = fields.Boolean('Overtime?', compute='_check_overtime')
    actual_overtime_hours = fields.Float('Actual Overtime Hours')
    approved_overtime = fields.Float('Approved Overtime')

    # Added a new bool field
    lock = fields.Boolean('Lock')

    @api.depends('addition_type_id', 'date', 'employee_id', 'type_of_value')
    def _check_overtime(self):
        """
        This will check the overtime type and set or reset the field to hide or display other fields
        --------------------------------------------------------------------------------------------
        @param self: object pointer
        """
        for add in self:
            add.is_overtime = add.addition_type_id == self.env.company.overtime_addtion_type_id

    @api.onchange('value_amount')
    def onchange_value_amount(self):
        self.value = self.value_amount

    @api.onchange('date', 'value', 'value_amount', 'type_of_value', 'addition_type_id', 'employee_id')
    def onchange_value_type(self):
        """
        This method will update the addition amount
        -------------------------------------------
        @param self: object pointer
        """
        tracking_line_obj = self.env['time.tracking.line']
        overtime_type = self.env.company.overtime_addtion_type_id
        for add in self:
            worked_hours = add.employee_id.count_working_hours(employee_id=add.employee_id, date=add.date)
            tracking_lines = tracking_line_obj.sudo().search([('employee_id', '=', add.employee_id.id),
                                                       ('date', '=', add.date)], limit=1)
            if overtime_type == add.addition_type_id:
                ot_hrs = (add.type_of_value == 'days') and add.value * worked_hours or add.value
                add.actual_overtime_hours = tracking_lines.overtime_hours
                add.approved_overtime = ot_hrs and ot_hrs or 0.0
                add.amount = add.sudo().employee_id.hourly_rate * add.approved_overtime
            else:
                if add.type_of_value == 'money':
                    add.amount = add.value
                elif add.type_of_value == 'hours':
                    add.amount = add.sudo().employee_id.hourly_rate * add.value
                elif add.type_of_value == 'days':
                    add.amount = add.sudo().employee_id.hourly_rate * add.value * worked_hours

    def action_pending(self):
        """
        This method will set the state of the addition to reset draft
        ----------------------------------------------------------
        @param self: object pointer
        """
        for add in self:
            if add.lock == True:
                raise UserError(_("You can not reset approved addition!"))
            add.state = 'pending'

    def action_approve(self):
        """
        This method will set the state of the addition to approved
        ----------------------------------------------------------
        @param self: object pointer
        """
        tracking_line = self.env['time.tracking.line'].sudo().search([('employee_id', '=', self.employee_id.id),
                                                               ('date', '=', self.date)], limit=1)
        for add in self:
            if tracking_line:
                add.write({'tracking_line_id': tracking_line.id})
            add.state = 'approved'

    def action_reject(self):
        """
        This method will open pop wizard for reject
        -------------------------------------------
        @param self: object pointer
        """
        return {
            'name': _("Hr Addition Reject Form"),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'hr.addition.reject.wizard',
            'target': 'new',
        }

    @api.constrains('addition_type_id', 'type_of_value')
    def check_addition_overtime(self):
        """
        This method will not allow the employee to create addition request for overtime when type value not hours
        ---------------------------------------------------------------------------------------------------------
        @parm self: object pointer
        """
        for add in self:
            if self.env.company.overtime_addtion_type_id == add.addition_type_id and add.type_of_value != 'hours':
                raise ValidationError(_('You can create addition overtime with only type of value hour!'))

    @api.constrains('type_of_value')
    def check_user(self):
        """
        This method will check that if user is not payroll manager / payroll user
        then user can not create an addition with type money.
        ----------------------------------------------------------------------
        @parm self: object pointer
        """
        for add in self:
            if add.type_of_value == 'money':
                if not self.env.user.has_group(
                        'sky_hr_payroll_custom.group_payroll_manager') or not self.env.user.has_group(
                        'sky_hr_payroll_custom.group_payroll_user'):
                    raise ValidationError(_('You can not create addition with type money! Please contact your Manager!'))

    def unlink(self):
        """
        Overridden the unlink method to restrict deletion of approved additions
        -----------------------------------------------------------------------
        @param self: object pointer
        :return True
        """
        for addition in self:
            if addition.state != 'pending' or addition.lock == True:
                raise UserError(_("You can not delete approved addition!"))
        return super(Addition, self).unlink()