import math
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression


class Leave(models.Model):
    _inherit = 'hr.leave'

    @api.constrains('date_from', 'date_to', 'state', 'employee_id', 'start_time', 'end_time')
    def _check_date(self):
        for holiday in self:
            exists_leave = self.sudo().search([
                ('date_from', '<', holiday.date_to),
                ('date_to', '>', holiday.date_from),
                ('end_time', '>=', holiday.start_time),
                ('start_time', '<=', holiday.end_time),
                ('employee_id', '=', holiday.employee_id.id),
                ('id', '!=', holiday.id),
                ('state', 'not in', ['cancel', 'refuse'])
            ])
            if exists_leave:
                start_time = "{:.2f}".format(exists_leave.start_time)
                end_time = "{:.2f}".format(exists_leave.end_time)
                raise ValidationError(_(
                    """You can not allow to add Leave Request because you have another %s leave"""
                    """ with same time %s to %s on the same day."""
                ) % (exists_leave.holiday_status_id.name, start_time , end_time))

    def create_penalty(self, penalty_type, pay_cut, tracking_line):
        """
        This method will create a penalty with attached leave type
        ----------------------------------------------------------
        @param self: object pointer
        @param penalty_type: Type of Penalty
        @param pay_cut: Pay Cut mentioned on Leave / Vacation
        @param tracking_line: Tracking line where this penalty should be added
        """
        penalty_obj = self.env['hr.penalty']
        for rec in self:
            penalty_vals = {
                'employee_id': rec.employee_id.id,
                'date': rec.request_date_from,
                'penalty_type_id': penalty_type.id,
                'value_type': 'pay_cut',
                'value': pay_cut,
                'amount': pay_cut,
                'reason': rec.name,
                'tracking_line_id': tracking_line.id,
            }
            penalty_obj.create(penalty_vals)

    def action_approve(self):
        """
        Overridden method of leave and vacation approval to create a penalty for paycut
        ----------------------------------------------------------------------------------------
        @param self : object pointer
        """
        res = super(Leave, self).action_approve()
        tracking_line_obj = self.env['time.tracking.line']
        for rec in self:
            if rec.leave_paycut or rec.vacation_paycut:
                tracking_line = tracking_line_obj.search([('employee_id', '=', rec.employee_id.id),
                                                          ('date', '=', rec.request_date_from)], limit=1)
                leave_type = rec.leave_type
                leave_penalty_type = rec.env.company.leave_penalty_type_id
                vaction_penalty_type = rec.env.company.vacation_penalty_type_id
                if tracking_line.penalty_ids.ids:
                    if leave_type == 'leave':
                        penalty = tracking_line.penalty_ids.filtered(
                            lambda rec: rec.penalty_type_id == leave_penalty_type)
                        if penalty.ids:
                            if penalty.state == 'approved':
                                raise UserError(_('You have a penalty approved, you need to cancel this penalty'))
                            elif penalty.state == 'rejected':
                                rec.create_penalty(leave_penalty_type, rec.leave_paycut)
                            penalty.write({
                                'value_type': 'pay_cut',
                                'value': rec.leave_paycut,
                                'amount': rec.leave_paycut
                            })
                        else:
                            rec.create_penalty(leave_penalty_type, rec.leave_paycut, tracking_line)
                    else:
                        penalty = tracking_line.penalty_ids.filtered(
                            lambda rec: rec.penalty_type_id == vaction_penalty_type)
                        if penalty.ids:
                            if penalty.state == 'approved':
                                raise UserError(_('You have a penalty approved, you need to cancel this penalty'))
                            elif penalty.state == 'rejected':
                                rec.create_penalty(vaction_penalty_type, rec.vacation_paycut, tracking_line)
                            penalty.write({
                                'value_type': 'pay_cut',
                                'value': rec.vacation_paycut,
                                'amount': rec.vacation_paycut,
                            })
                        else:
                            rec.create_penalty(leave_type, vaction_penalty_type, rec.vacation_paycut, tracking_line)
                else:
                    if rec.leave_type == 'leave':
                        rec.create_penalty(leave_penalty_type, rec.leave_paycut, tracking_line)
                    else:
                        rec.create_penalty(vaction_penalty_type, rec.vacation_paycut, tracking_line)
        return res
