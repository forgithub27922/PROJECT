# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#
##############################################################################
from odoo import models, fields, api, _
from dateutil.relativedelta import relativedelta as rd


class Employee(models.Model):
    _inherit = 'hr.employee'

    addition_ids = fields.One2many('hr.addition', 'employee_id', 'Additions')
    penalty_ids = fields.One2many('hr.penalty', 'employee_id', 'Penalties')
    hourly_rate = fields.Float('Hourly Rate', help='This rate will be used for creating penalties and additions')
    salary_schedule = fields.Selection([('1', '1st of Month'), ('15', '15th of Month')], 'Salary Schedule', default='1')
    next_salary_date = fields.Date('Next Salary Date')

    @api.onchange('salary_schedule')
    def onchange_schedule(self):
        """
        This method is used to set the next salary date
        -----------------------------------------------
        @param self: object pointer
        """
        cr_date = fields.Date.today()
        for emp in self:
            next_salary_date = False
            if emp.salary_schedule:
                if emp.salary_schedule == '1':
                    next_salary_date = cr_date + rd(day=1)
                elif emp.salary_schedule == '15':
                    next_salary_date = cr_date + rd(day=15)
                if next_salary_date < cr_date:
                    next_salary_date += rd(months=1)
                emp.next_salary_date = next_salary_date

    @api.model
    def cron_create_salary(self):
        """
        This method will create salary for all the employees who have next salary date as current date
        ----------------------------------------------------------------------------------------------
        @param self: object pointer
        """
        salary_obj = self.env['hr.employee.salary']
        penalty_obj = self.env['hr.penalty']
        add_obj = self.env['hr.addition']
        cr_date = fields.Date.today()
        # Search for employees who's salary is due today
        emps = self.search([('next_salary_date', '=', cr_date)])
        # Get Salary Start Date and End Date
        sal_start_date = cr_date - rd(months=1)
        sal_end_date = cr_date - rd(days=1)
        for emp in emps:
            # Create Vals for Salary
            salary_vals = {
                'employee_id': emp.id,
                'start_date': sal_start_date,
                'end_date': sal_end_date,
                'basic': emp.salary,
                'annual_bonus': emp.annual_bonus
            }
            # Add Penalties for the employee
            penalties = penalty_obj.search([('employee_id', '=', emp.id),
                                            ('date', '>=', sal_start_date),
                                            ('date', '<=', sal_end_date),
                                            ('state', '=', 'approved')])
            salary_vals.update({
                'penalty_ids': [(6, 0, penalties.ids)]
            })
            # Add Additions for the employee
            additions = add_obj.search([('employee_id', '=', emp.id),
                                        ('date', '>=', sal_start_date),
                                        ('date', '<=', sal_end_date),
                                        ('state', '=', 'approved')])
            salary_vals.update({
                'addition_ids': [(6, 0, additions.ids)]
            })
            # Create Salary
            salary_obj.create(salary_vals)
            # set the Next Salary Date
            emp.next_salary_date = cr_date + rd(months=1)

    def count_working_hours(self, employee_id, date):
        """
           This method will work hours calculation from the Working Schedules
           ------------------------------------------------------------------
           @param self: object pointer
        """
        working_hours = 0.0
        for attendance in employee_id.resource_calendar_id.attendance_ids:
            if attendance.dayofweek == date.strftime('%w'):
                working_hours += attendance.working_hours
        return working_hours
