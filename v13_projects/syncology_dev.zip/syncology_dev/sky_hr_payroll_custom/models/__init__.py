from . import hr_addition
from . import hr_penalty
from . import hr_employee_salary
from . import hr_employee
from . import res_company
from . import res_config_settings
from . import hr_leave
from . import hr_time_tracking
