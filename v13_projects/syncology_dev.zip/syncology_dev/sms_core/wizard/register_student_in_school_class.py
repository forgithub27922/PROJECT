# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.
from odoo import models, fields, api,_
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression
import requests, json
from datetime import datetime, timedelta
from datetime import datetime
from datetime import date
from _ast import Try
from email.policy import default
from odoo.addons.test_convert.tests.test_env import field
from odoo.tools.mail import append_content_to_html
import string


class AdmitStudentInSchool(models.TransientModel):
 
    _name = 'admit.student.school.wizard'
    _description = 'admit.student.school.wizard'
    
    line_rec_id =fields.Many2one('student.class')
    parent_id = fields.Many2one('academic.student')
    admission_id = fields.Many2one('student.admission.form')
    school_id = fields.Many2one('schools.list',string = 'School', domain="[('active', '=', True)]")
    class_grade_id = fields.Many2one('school.class',string='Grade')
    section_id = fields.Many2one('class.section',string='Class')
    max_capacity = fields.Integer(string='Max Capacity', readonly=True)
    current_strength = fields.Integer(string='Current Strength', readonly=True)
    class_course_ids = fields.Many2many('class.course', string='Courses')
    wizard_mode = fields.Selection([('admission', 'Admission'), ('academic_student', 'Academic Student')], string='Mode',default='admission')
    
    def register_student_in_school_class(self):
        parent_name = ''
        admission_id = self.env.context.get('admission_id', False)
        rec = self.env['student.admission.form'].browse(admission_id)
        rec.school_id = self.school_id.id
        rec.class_id = self.class_grade_id.id
        
        if not rec.father_is_absent:
            print("Father is absent")
            parent_name = rec.father_full_name
        elif not rec.mother_is_absent:
            print("mather  is absent")
            parent_name = rec.mother_full_name
        else:
            print("Both are absent")
            parent_name = rec.guardian_full_name
        parent_name = parent_name.strip()
        parent_name_str_arr = parent_name.split(" ")
        parent_first_name = parent_name_str_arr[0]
        parent_last_name = ''
        for x in range(1, len(parent_name_str_arr)):
            parent_last_name = str(parent_last_name) + " " + str(parent_name_str_arr[x])

        std_unique_id = rec.id
        std_name = rec.first_name
        std_first_name = std_name.split()[0]
        school_domain = self.school_id.domain_name
        
        std_email_prefix = 'st.'
        parent_email_prefix = 'pr.'
        
        if std_unique_id:
            temp_seq = str(std_unique_id).zfill(5)
        std_email = str(std_email_prefix)+str(std_first_name.lower())+str(temp_seq)+"@"+str(school_domain)
        parent_email = str(parent_email_prefix)+str(parent_first_name.lower())+str(temp_seq)+"@"+str(school_domain)
        std_password = 'st_'+str(std_first_name.lower())+str(temp_seq)+'_sync'
        std_email = std_email.replace(" ", "") 
#         full_name = rec.name.split()
        first_name = rec.first_name
        last_name = str(rec.middle_name) + " " + str(rec.second_middle_name) + " " + str(rec.last_name)
        # if last_name:
            # last_name = rec.first_name
        ############CREATE STUDENT ON MOODEL###############################
        try:
            print("this is student password",std_password)
            parameters= '&users[0][username]='+str(std_email.strip())+'&users[0][firstname]='+str(first_name)+'&users[0][lastname]='+str(last_name)+'&users[0][email]='+str(std_email)+'&users[0][createpassword]=1'+'&users[0][password]='+str(std_password)+'&users[0][phone1]=0915833860'
            moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246'+parameters+'&wsfunction=core_user_create_users&moodlewsrestformat=json'
            head_params = {'wsfunction':'core_user_create_users', 'moodlewsrestformat':'json'}
            response = requests.get(moodle_url, params=head_params)
            response = response.json()
            if response:
                if 'errorcode' in response:
                    print("Create Student/user on moodle",response['debuginfo'])
                else:
                    response = response[0]
                    if 'id' in response:
                        rec.mooddle_id = response['id']
                        rec.md_password = std_password
                        rec.md_username = std_email
                        rec.md_parent_username = parent_email
                        #update password
                        parameters = '&users[0][id]=' + str(response['id']) + '&users[0][password]=' + str(std_password)
                        moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_user_update_users&moodlewsrestformat=json'
                        head_params = {'wsfunction':'core_user_update_users', 'moodlewsrestformat':'json'}
                        response = requests.get(moodle_url, params=head_params)
                        response = response.json()
                        print("this is the response",response)
        except:
            raise UserError(_('Record not created on lms contact your system administrator'))
        #################### END CREATE STUDENT ON MOODEL #######################
        
        
        
        parent_email = parent_email.replace(" ", "")  
        ############CREATE PARENT ON MOODEL################################## 
        try:
            parameters= '&users[0][username]='+str(parent_email.strip())+'&users[0][firstname]='+str(parent_first_name)+'&users[0][lastname]='+str(parent_last_name)+'&users[0][email]='+str(parent_email)+'&users[0][createpassword]=1'+'&users[0][password]='+str(std_password)+'&users[0][phone1]=0915833860'
            moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246'+parameters+'&wsfunction=core_user_create_users&moodlewsrestformat=json'
            head_params = {'wsfunction':'core_user_create_users', 'moodlewsrestformat':'json'}
            response = requests.get(moodle_url, params=head_params)
            response = response.json()
            if response:
                if 'errorcode' in response:
                    print("Parent create error response",response['debuginfo'])
                else:
                    response = response[0]
                    if 'id' in response:
#                         rec.md_password = first_part
                        rec.md_parent_username = parent_email
        except:
            raise UserError(_('Record not created on lms contact your system administrator'))
                    
        std_family = self.env['student.parent.guardian.info'].create({
                    #Father
                    'father_full_name': rec.father_full_name,
                    'father_full_name_arabic': rec.father_full_name_arabic,
                    'father_national_id': rec.father_national_id,
                    'father_nationality': rec.father_nationality.id,
                    'father_marital_status': rec.father_marital_status,
                    'father_degree_education': rec.father_degree_education,
                    'father_employment': rec.father_employment,
                    'father_employer_location': rec.father_employer_location,
                    'father_landline_number': rec.father_landline_number,
                    'father_land_line_no': rec.father_land_line_no,
                    'father_mobile_no': rec.father_mobile_no,
                    'father_email': rec.father_email,
                    'father_is_absent': rec.father_is_absent,
                    #Mother
                    'mother_full_name': rec.mother_full_name,
                    'mother_full_name_arabic': rec.mother_full_name_arabic,
                    'mother_national_id': rec.mother_national_id,
                    'mother_nationality': rec.mother_nationality.id,
                    'mother_marital_status': rec.mother_marital_status,
                    'mother_degree_education': rec.mother_degree_education,
                    'mother_employment': rec.mother_employment,
                    'mother_employer_location': rec.mother_employer_location,
                    'mother_landline_number': rec.mother_landline_number,
                    'mother_land_line_no': rec.mother_land_line_no,
                    'mother_mobile_no': rec.mother_mobile_no,
                    'mother_email': rec.mother_email,
                    'mother_is_absent': rec.mother_is_absent,
                    #Guardian
                    'legal_guardian': rec.legal_guardian,
                    'guardian_full_name': rec.guardian_full_name,
                    'guardian_full_name_arabic': rec.guardian_full_name_arabic,
                    'guardian_national_id': rec.guardian_national_id,
                    'guardian_nationality': rec.guardian_nationality.id,
                    'guardian_marital_status':rec.guardian_marital_status,
                    'relation_to_child': rec.relation_to_child,
                    'guardian_degree_education': rec.guardian_degree_education,
                    'guardian_employment': rec.guardian_employment,
                    'guardian_employeer_location': rec.guardian_employeer_location,
                    'guardian_landline_number': rec.guardian_landline_number,
                    'guardian_land_line_no': rec.guardian_land_line_no,
                    'guardian_mobile_no': rec.guardian_mobile_no,
                    'guardian_email': rec.guardian_email,
                    
                    })
        
        std_id = self.env['academic.student'].create({
                    'student_image': rec.student_image,
                    'full_name': str(rec.first_name) + " " + str(rec.middle_name) + " " + str(rec.second_middle_name) + " " + str(rec.last_name),
                    'first_name': rec.first_name,
                    'middle_name': rec.middle_name,
                    'second_middle_name': rec.second_middle_name,
                    'last_name': rec.last_name,
                    'first_name_arabic': rec.first_name_arabic,
                    'middle_name_arabic': rec.middle_name_arabic,
                    'second_middle_name_arabic': rec.second_middle_name_arabic,
                    'last_name_arabic': rec.last_name_arabic,
                    'full_name_arabic': str(rec.first_name_arabic) + " " + str(rec.middle_name_arabic) + " " + str(rec.second_middle_name_arabic) + " " + str(rec.last_name_arabic),
                    'father_mobile_no':rec.father_mobile_no,
                    'mother_mobile_no':rec.mother_mobile_no,
                    'guardian_mobile_no':rec.guardian_mobile_no,
                    'national_id': rec.national_id,
                    'passport_id': rec.passport_id,
                    'nationality': rec.nationality.id,
                    'birth_date': rec.birth_date,
                    'birth_place': rec.birth_place,
                    'city': rec.city,
                    'address': rec.address,
                    'gender': rec.gender,
                    'religion': rec.religion,
                    'application_for': rec.application_for,
                    'school_id': self.school_id.id,
                    'class_id': self.class_grade_id.id,
                    'class_section_id': self.section_id.id,
                    'prevous_school': rec.prevous_school,
                    'primary_language':rec.primary_language,
                    'second_language':rec.second_language,
                    'sibing_status': rec.sibing_status,
                    'mooddle_id':rec.mooddle_id,
                    'md_username':rec.md_username,
                    'md_password':rec.md_password,
                    'md_parent_username':rec.md_parent_username,
                    'moodle_status': 'active',
                    'state': 'admitted',
                    'family_id': std_family.id,
                    })
        
        std_class = self.env['student.class'].create({
                    'student_id': std_id.id,
                    'class_id': self.class_grade_id.id,
                    'class_section_id':self.section_id.id,
                    'status': 'active',
                    })
        
        if std_class:
            sendingData = []
            recipientData = []
            today = datetime.now()
            current_month = today.strftime("%m")
            current_year = today.strftime("%Y")
            admission_id = self.env['student.admission.form'].search([('id', '=', rec.id)])
            if admission_id.state == 'payment':
                info = {
                    "name": admission_id['full_name'] if admission_id['full_name'] else '',
                    "school_name": admission_id['school_id'].name if admission_id['school_id'] else '',
                    "Class_name": admission_id['class_id'].name if admission_id['class_id'] else '',
                    "std_user_name": rec.md_username if rec.md_username else '',
                    "parent_user_name": rec.md_parent_username if rec.md_parent_username else '',
                    "moodle_password": rec.md_password if rec.md_password else '',
                }
                sendingData.append(info)
#             managers = self.env['res.users'].search([('groups_id', '=', 'Employees / Manager'), ('active', '=', True)])
#             recipientData = [str(i.email) for i in managers if type(i.email) is not bool]
            print(recipientData)
            if len(sendingData) > 0:
                print("Sending data", sendingData)
                body_html = """
                    <div>
                    <p>We would like to inform you that your payment for has been received and """ + str(sendingData[0]['name']) + """ has 
                    been admitted to """ + str(sendingData[0]['Class_name']) + """. You and """ + str(sendingData[0]['name']) + """ can now
                    access our school’s super powerful learning management system EduSync, through the following link: <br />
                    <a target="_blank" href="http://35.192.148.38/login/index.php">Goto Moodle LMS</a>
                    <link to moodle lms> where you can view """ + str(sendingData[0]['name']) + """’s academic activity and grades, 
                    and """ + str(sendingData[0]['name']) + """ can start a new amazing learning journey. For more information please visit the following link: 
                    <link to information from students affairs module> """ + str(sendingData[0]['name']) + """ access credentials are: <br />
                    User Name : """ + str(sendingData[0]['std_user_name']) + """ <br />
                    Login Password : """ + str(sendingData[0]['moodle_password']) + """ <br />
                    <credentials from students affairs module> <br />
                    Parent credentials are: <br />
                    User Name : """ + str(sendingData[0]['parent_user_name']) + """ <br />
                    Login Password : """ + str(sendingData[0]['moodle_password']) + """ <br />
                    <parent credentials from students affairs module> <br />
                    We happily welcome you and """ + str(sendingData[0]['name']) + """ to our family, Have a wonderful year, 
                    and see you on """ + str(sendingData[0]['name']) + """’s first day.” 
 
                    </p>
                    </div>
                    """ 
                print("Sending data after body", sendingData)
                mail_pool = self.env['mail.mail']
                if admission_id.father_email:
                    recipientData.append(admission_id.father_email)
                if admission_id.mother_email:
                    recipientData.append(admission_id.mother_email)
                if admission_id.legal_guardian != 'father_is_legal_guardian':
                    if admission_id.guardian_email:
                        recipientData.append(admission_id.guardian_email)
                values = {}
                values.update({'subject': 'Admission: '+str(sendingData[0]['name']) or '--' + ' Admission Confirmed'})
                values.update({'email_to': ','.join(recipientData)})
                values.update({'email_to': ','.join(recipientData)})
                values.update({'body_html': body_html})
                values.update({'body': body_html})
                msg_id = mail_pool.create(values)
                if msg_id:
                    msg_id.send()
                rec.date_of_admission = datetime.now()
                rec.admitted_by = self._uid
                rec.state = 'admitted'
        return
    
    
    def action_change_student_class(self):
        parent_id = self.env.context.get('parent_id', False)
        rec = self.env['academic.student'].browse(parent_id)
        std_class_obj = rec.student_classes_ids
        std_courses_obj = rec.student_courses_ids
        for f in std_class_obj:
            if f.status == 'active':
                f.status = 'closed'
        for cr in std_courses_obj:
            if cr.course_status == 'active':
                cr.course_status = 'closed'
                
        std_class = self.env['student.class'].create({
                    'student_id': rec.id,
                    'class_id': self.class_grade_id.id,
                    'status': 'active',
                    })
    
    @api.onchange('school_id')
    def onchange_domain(self):
        self.class_grade_id = ''
        self.class_course_ids = None
        ids_list_class_grade =[]
        if self.school_id:
            if not self.school_id.domain_name:
                raise UserError(_('Domain name is not set for school. Set a domain name on school form'))
        for f in  self.school_id.school_class_ids:
            ids_list_class_grade.append(f.id)
        return {'domain': {'class_grade_id': [('id', 'in', ids_list_class_grade)]}}
    
#     @api.onchange('class_grade_id')
#     def class_onchange_domain(self):
#         self.class_course_ids = None
#         class_course_ids_list =[]
#         course_list = self.env['class.course'].search([('class_id','=',self.class_grade_id.id),('active','=',True)])
#         for f in course_list:
#             class_course_ids_list.append(f.id)
#         self.class_course_ids = class_course_ids_list
#         return {'domain': {'class_course_ids': [('id', 'in', class_course_ids_list)]}}
    
    @api.onchange('class_grade_id')
    def class_onchange_domain(self):
        self.section_id = None
        class_section_ids_list =[]
        #the following 2 lines are commented due to client requ he wants classes should not be dependent on grades
        #sections_list = self.env['class.section'].search([('grade_id','=',self.class_grade_id.id)])
        #sections_list2 = self.env['class.section'].search([('grade_id','=',self.class_grade_id.id)],order='sequence_no')
        
        sections_list = self.env['class.section'].search([])
        sections_list2 = self.env['class.section'].search([],order='sequence_no')
        
        for rec in sections_list2:
            if rec.current_strength+1 <= rec.max_capacity:
                self.section_id = rec.id
                break
        for f in sections_list:
            class_section_ids_list.append(f.id)
        self.class_section_ids = class_section_ids_list
        return {'domain': {'section_id': [('id', 'in', class_section_ids_list)]}}
    
    @api.onchange('section_id')
    def section_onchange_domain(self):
        self.max_capacity = None
        self.current_strength = None
        for f in self.section_id:
            self.max_capacity = f.max_capacity
            self.current_strength = f.current_strength
        return
