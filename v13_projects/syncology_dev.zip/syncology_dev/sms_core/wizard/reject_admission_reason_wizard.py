# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _
from odoo.exceptions import UserError, ValidationError
from datetime import datetime
from odoo.tools.mail import append_content_to_html


class AdmitStudentInSchool(models.TransientModel):
 
    _name = 'admission.reject.reason.wizard'
    _description = 'admission.reject.reason.wizard'
    
    admission_id = fields.Many2one('student.admission.form')
    adm_reject_reason = fields.Text('Reason')

    def reject_student_admission(self):
        
        adm_id = self.env.context.get('admission_id', False)
        rec = self.env['student.admission.form'].browse(adm_id)
        
        try:
            sendingData = []
            recipientData = []
            today = datetime.now()
            current_month = today.strftime("%m")
            current_year = today.strftime("%Y")
            admission_id = self.env['student.admission.form'].search([('id', '=', adm_id)])
            if admission_id.state in ('interview', 'documentation', 'payment'):
                info = {
                    "name": admission_id['full_name'] if admission_id['full_name'] else '',
                    "reason": self.adm_reject_reason if self.adm_reject_reason else '',
                }
                sendingData.append(info)
#             managers = self.env['res.users'].search([('groups_id', '=', 'Employees / Manager'), ('active', '=', True)])
#             recipientData = [str(i.email) for i in managers if type(i.email) is not bool]
            if len(sendingData) > 0:
                body_html = """
                    <div>
                    <p>We regret to inform you that """ + str(sendingData[0]['name']) + """  cannot join us for the following reasons:<br /> 
                    """ + str(sendingData[0]['reason']) + """ We are sure that many schools out there will be lucky to have 
                    """ + str(sendingData[0]['name']) + """, yet It was an honor that you chose us first. Thank you and we wish you and 
                    """ + str(sendingData[0]['name']) + """ all the best. 
                    </p>
                    </div>
                    """ 

                mail_pool = self.env['mail.mail']
                values = {}
                values.update({'subject': 'Admission: Admission Email '})
#                 values.update({'email_to': ','.join(recipientData)})
                values.update({'email_to': 'wfrisson@gmail.com'})
                values.update({'body_html': body_html})
                values.update({'body': body_html})
                msg_id = mail_pool.create(values)
                if msg_id:
                    msg_id.send()
                rec.state = 'rejected'
                rec.date_of_reject_cancel = datetime.now()
                rec.rejected_by = self._uid
            
        except Exception as e:
            raise ValidationError(e)
        
        
        

        return
    
    
    @api.onchange('school_id')
    def onchange_domain(self):
        self.class_grade_id = ''
        self.class_course_ids = None
        ids_list_class_grade =[]
        for f in  self.school_id.school_class_ids:
            ids_list_class_grade.append(f.id)
        return {'domain': {'class_grade_id': [('id', 'in', ids_list_class_grade)]}}
    
    @api.onchange('class_grade_id')
    def class_onchange_domain(self):
        self.class_course_ids = None
        class_course_ids_list =[]
        course_list = self.env['class.course'].search([('class_id','=',self.class_grade_id.id),('active','=',True)])
        for f in course_list:
            class_course_ids_list.append(f.id)
        self.class_course_ids = class_course_ids_list
        return
    
    
