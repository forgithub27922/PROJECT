# -*- coding: utf-8 -*-
from odoo import models, fields, api,_
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression
import requests, json
from datetime import datetime, timedelta
from datetime import datetime
from datetime import date
from _ast import Try
from email.policy import default
from odoo.addons.test_convert.tests.test_env import field
import string
from pickletools import string1


class FeePolicy(models.Model):
    _name = 'fee.policy'
    _description = 'Fee Policy'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'start_date desc'
    
    @api.model
    def create(self, vals):
        records = self.search([])
        policy_obj = None
        if vals['start_date']:
            for rec in records:
                if vals['start_date'] <= str(rec.end_date):
                    raise UserError(_('Fee policy in current date range already exists.'))
                
        policy_obj = super(FeePolicy, self).create(vals)
        return policy_obj
    
    def unlink(self):
        if self.state != 'draft':
            raise UserError(_('Only fee policy in draft state can be deleted.'))
        else:
            rec = super(FeePolicy, self).unlink()   
        return  
    
    def compute_feepolicy_name(self):
        for fp in self:
            month=''
            year=''
            if fp.start_date:
                month = str(datetime.strptime(str(fp.start_date), '%Y-%m-%d').strftime('%B')[:3]).upper()
                year = str(datetime.strptime(str(fp.start_date), '%Y-%m-%d').strftime('%Y'))
            fp.name = 'FP'+str(fp.id)+"-"+str(month)+"-"+str(year)
        return
    
    def _compute_total_amount(self):
        for f in self:
            f.total_amount = f.semester_fee + f.uniform_fee + f.books_fee + f.activities_fee
    
    def compute_fee_policy_status(self):
        for fp in self:
            today = datetime.now()
            if fp.start_date > today.date():
                fp.state = 'draft'
            elif fp.start_date <= today.date() <= fp.end_date:
                fp.state = 'active'
            else:
                fp.state = 'closed'
    
    @api.onchange('start_date','end_date')
    def onchange_fee_date_comparison(self):
        if self.start_date and self.end_date:
            if self.end_date < self.start_date:
                raise UserError(_('End date must be greater than start date'))
    
    @api.onchange('no_of_installments','semester_fee','start_date','end_date')
    def onchange_no_of_installments(self):
        self.fee_policy_line_ids = None
        if self.no_of_installments>0:
            if self.start_date:
                next_fee_date = self.start_date + timedelta(days = 30)
                print("This is time difference ====== ",next_fee_date)
            
            installment_list = []
            if self.no_of_installments != 0:
                installment_amount = self.semester_fee / self.no_of_installments
                
                for f in range(1, self.no_of_installments+1):
                    if f == 1:
                        next_fee_date = self.start_date
                    else:
                        if next_fee_date:
                            next_fee_date = next_fee_date + timedelta(days = 30)
                    
                    fee_installments = (0, 0, {'installment_no': f ,'fee_type': 'semester_fee' , 'date': next_fee_date , 'due_date': '' , 'amount': installment_amount})
                    installment_list.append(fee_installments)
            self.fee_policy_line_ids = installment_list
        
    name = fields.Char(string = 'Fee Policy',compute='compute_feepolicy_name')
    semester_fee = fields.Float('Semester Fee', required="1", tracking=True)
    uniform_fee = fields.Float('Uniform Fee', required="1", tracking=True)
    books_fee = fields.Float('Books Fee', required="1", tracking=True)
    activities_fee = fields.Float('Activities Fee', required="1", tracking=True)
    no_of_installments = fields.Integer('No of Installments')
    total_amount = fields.Float('Total Amount', compute="_compute_total_amount")
    warning_email = fields.Integer('Warning Email')
    start_date = fields.Date('Start Date', required="1", tracking=True)
    end_date = fields.Date('End Date', required="1", tracking=True)
    state = fields.Selection([('draft', 'Draft'),('active', 'Active'), ('closed', 'Closed')], compute="compute_fee_policy_status", string='Status',tracking=True)

    #Discounts
    employee_child_discount = fields.Float('Employee Child')
    siblings_discount = fields.Float('Sibling Discount')
    fee_policy_line_ids = fields.One2many('fee.policy.line', 'fee_policy_id', string="Fee Lines")
    
class FeePolicyLine(models.Model):
    _name = 'fee.policy.line'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'fee.policy.line'
     
    
    def write(self, vals):
        super(FeePolicyLine, self).write(vals)
        #self.update_student_fee_register()
        
        return
    
    def unlink(self):
        for fr in self:
            
            rec = self.env['student.fee'].search([('fee_policy_line_id','=',fr.id)])
            print("unlink called",len(rec))
            if len(rec)>0:
                raise UserError(_('Fee Installment cannot be deleted as it applied on some students'))
            else:
                fr.fee_policy_id.message_post(body='Fee Installment deleted '+str(fr.name))
                super(FeePolicyLine, fr).unlink()
        return
    
    def compute_name(self):
        for line in self:
            f = str(line.installment_no).zfill(2)
            if line.date:
                month = str(datetime.strptime(str(line.date), '%Y-%m-%d').strftime('%B')[:3]).upper()
                year = str(datetime.strptime(str(line.date), '%Y-%m-%d').strftime('%Y'))
                line.name = 'INST'+str(f)+'-'+str(month)+str(year)+"-"+str(line.fee_policy_id.id)
            else:
                line.name = 'INST-'+str(f)
        return
    
    def compute_warning_email_date(self):
        for pl in self:
           # pl.warning_email_date = '2021-12-2021'
            parent_week = pl.fee_policy_id.warning_email
            if parent_week:
                if parent_week == 1:
                    days = 10
                elif parent_week == 2:
                    days = 14
                elif parent_week == 3:
                    days = 21
                elif parent_week == 4:
                    days = 28
                else:
                    days = 10
                if pl.due_date:
                    new_date = pl.due_date - timedelta(days)
                    if pl.date < new_date < pl.due_date:
                        pl.warning_email_date = new_date
                    else:
                        pl.warning_email_date =None
                else:
                    pl.warning_email_date = None
            else:
                pl.warning_email_date = None
        return 
    
    def update_student_fee_register(self,policy_lin_rec,call_method):
        """"
        This method will be updated by cron job also by button click
        """
        student_ids = self.env['academic.student'].search([('state', '=', 'admitted')])
        exists_count = 0
        new_records_count = 0
        for std in student_ids:
            emp_child = 0
            sibling_disc = 0
            
            #calculate discount if student is sibling or staff child
            allowed_disc = std.sibing_status
            if allowed_disc == 'has_brothers_sisters':
                disc_per = policy_lin_rec.fee_policy_id.siblings_discount
                if disc_per >0:
                    if policy_lin_rec.fee_type == 'semester_fee':
                        sibling_disc = policy_lin_rec.amount*(disc_per/100)
                        emp_child = 0
            elif allowed_disc == 'staff_child':
                disc_per = policy_lin_rec.fee_policy_id.employee_child_discount
                if disc_per >0:
                    if policy_lin_rec.fee_type == 'semester_fee':
                        emp_child = policy_lin_rec.amount*(disc_per/100)
                        sibling_disc = 0

            exists = self.env['student.fee'].search([('student_id','=',std.id),('fee_policy_line_id','=',policy_lin_rec.id)])
            print("exists..",exists)
            if exists:
                if exists.status == 'unpaid':
                    dictt = {
                            'fee_date': policy_lin_rec.date,
                            'due_date': policy_lin_rec.due_date,
                            'total_amount': policy_lin_rec.amount,
                            'sibling_disc': sibling_disc,
                            'emp_chil_disc':emp_child
                            }
                    update = exists[0].write(dictt)
            elif not exists:
                new = self.env['student.fee'].create({
                        'student_id': std.id,
                        'fee_date': policy_lin_rec.date,
                        'due_date': policy_lin_rec.due_date,
                        'total_amount': policy_lin_rec.amount,
                        'sibling_disc': sibling_disc,
                        'emp_chil_disc':emp_child,
                        'fee_policy_id': policy_lin_rec.fee_policy_id.id,
                        'fee_policy_line_id': policy_lin_rec.id,
                        'status': 'unpaid',
                        })
                print("++++++++ Not Exist ++++++++")
                if new:
                    new_records_count = new_records_count + 1
                    std.message_post(body='New Fee record inserted for '+str(policy_lin_rec.name)+" via a"+str(call_method))
            else:
                exists_count = exists_count +1 
                std.message_post(body='Fee Register updated for '+str(policy_lin_rec.name)+" via a"+str(call_method))
                exists[0].write({'due_date':policy_lin_rec.due_date,'total_amount':policy_lin_rec.amount,'emp_chil_sibling_disc':disc_amt})
        #self.message_post(body='Updating Student Fee Register for '+str(self.name)+'\nTotal '+str(len(student_ids))+' active students found.'+str(exists)+' already updated,'+str()+' New Fee records created.')
        policy_lin_rec.fee_policy_id.message_post(body='Updated Student Fee Register for '+str(policy_lin_rec.name)+'\nTotal '+str(len(student_ids))+' active students found.'+str(exists_count)+' already updated,'+str(new_records_count)+' New Fee records created.'+"--"+str(call_method))
        
        return
    
    
    def call_warning_email_wizard(self):
        student_ids = self.env['academic.student'].search([('state', '=', 'admitted')])
        print("check that rec exist ++++++ ", student_ids)
        
        if student_ids:
            form_id = self.env.ref('sms_core.view_send_fee_overdue_email_wizard', False)
            return {
            'name': 'Send Warning Email',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'fee.overdue.warning.email.wizard',
            'view_id'   : form_id.id,
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context'   :{
                'default_installment_id':self.id,
                'default_intallment_name':self.name,
                'default_warning_date':self.warning_email_date,
                'default_due_date':self.due_date,
                'default_student_ids':student_ids.ids,
                          }}
    
    def call_payment_fee_wizard(self):
        std_fee_ids = self.env['student.fee'].search([('fee_policy_line_id', '=', self.id),('status', '=', 'unpaid')])
        print("check that rec exist ++++++ ", std_fee_ids)
        
        if std_fee_ids:
            form_id = self.env.ref('sms_core.view_student_fee_payment_wizard', False)
            return {
            'name': 'Pay Student Fee',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'student.fee.payment.wizard',
            'view_id'   : form_id.id,
            'type': 'ir.actions.act_window',
            'target': 'new',
            'context'   :{
                'default_installment_id':self.id,
                'default_student_fee_ids':std_fee_ids.ids,
                          }}
    
    
    def compute_policyline_fees(self):
        if self:
            for pl in self:
                pl.total_fee_charged = 0
                pl.discount_given = 0
#                 if pl.fee_policy_id:
#                     sql1 = """SELECT  COALESCE(sum(total_amount),'0')  FROM student_fee
#                               WHERE fee_policy_line_id = """+str(pl.id)+ """ AND status in('unpaid','paid') """  
#                              
#                     self.env.cr.execute(sql1)
#                     result = self.env.cr.fetchone()
#                     actual_fee = result[0]
#                     pl.actual_fee = actual_fee
#                     
#                     sql2 = """SELECT  COALESCE(sum(emp_chil_sibling_disc),'0') + COALESCE(sum(cash_discount),'0')  FROM student_fee
#                               WHERE fee_policy_line_id = """+str(pl.id)+ """ AND status ='paid' """  
#                              
#                     self.env.cr.execute(sql2)
#                     disc = self.env.cr.fetchone()[0]
#                     pl.discount_given = disc
            
        
        return
    
    name = fields.Char(string = 'Fee',compute='compute_name')
    fee_policy_id = fields.Many2one('fee.policy', string="Fee Policy")
    installment_no = fields.Integer('Installment No')
    fee_type = fields.Selection([('semester_fee', 'Semester Fee'), ('uniform_fee', 'Uniform Fee'),('books_fee', 'Books Fee'),('activities_fee', 'Activities Fee')], string='Fee Type',tracking=True)
    date = fields.Date('Fee Date')
    warning_email_date = fields.Date(string = 'Warning Email', compute='compute_warning_email_date')
    due_date = fields.Date('Due Date')
    amount = fields.Float('Amount')
    currency_id = fields.Many2one('res.currency', string='Currency', readonly=True,  default=lambda self: self.env.company.currency_id)
    total_fee_charged = fields.Monetary('Total Fee', compute = 'compute_policyline_fees',currency_field='currency_id', help="Fee charged against student. Without discount")
    applied_fee = fields.Monetary('Applied Fee',currency_field='currency_id',  help="Fee charged against student. After Discount")
    discount_given = fields.Monetary('Discount Given', currency_field='currency_id', help="Total discount diven against this installment.Showing for paid fee only")
    collections = fields.Monetary('Collections', currency_field='currency_id', help="Collections")
    outsandings = fields.Monetary('Fee Balance',  currency_field='currency_id',help="Fee still not paid.")
    student_fee_ids = fields.One2many('student.fee', 'fee_policy_line_id', string="Student Fee")
    
class StudentFee(models.Model):
    _name = 'student.fee'
    _description = 'student.fee'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    
    def unlink(self):
        for fr in self:
            raise UserError(_('Deleting Fee Records not allowed, use Fee cancel option instead.'))
        return 
    
    def cron_warning_email(self):
        """
        This method is called, by a cron job to send warning email to student.
        """
        fee_ids = self.env['student.fee'].search([('status','=','unpaid'),('is_overdue','=',True)])
        self.overdue_warning_email(fee_ids)
    
    def overdue_warning_email(self,fee_ids):
        """"
        This is central method it will send warning email to guardians if fee overdue date
        passed created by ------- Sohail 17-June-2021
        Called from 
        1. Wizard ----> warning email wizard,
        2. Cron Job ----> called from cron job with button click
        """
        
        sendingData = []
        recipientData = []
        today = datetime.now()
        current_month = today.strftime("%m")
        current_year = today.strftime("%Y")
        
        for f in fee_ids:
            if f.status == 'unpaid':
                info = {
                    "std_name": f.student_id.full_name if f.student_id.full_name else '',
                    "installment_id": f.name if f.name else '',
                    "name": f.name if f.name else '',
                    "amount": f['total_amount'] if f['total_amount'] else '',
                    "due_date": f['due_date'] if f['due_date'] else '',
                }
                sendingData.append(info)
                f.student_id.message_post(body='Fee overdue warning email sent to '+str(f.student_id.full_name))
                print("this is sending data ++--++--++--++ ",sendingData)

            if len(sendingData) > 0:
                body_html = """
                    <div>
                    <p>This is a reminder for payment: <br />
                        Amount: """ + str(sendingData[0]['amount']) + """ <br />
                        Due Date: """ + str(sendingData[0]['due_date']) + """ <br />
                        We wish you a good day. 
                    </p>
                    </div>
                    """ 

                mail_pool = self.env['mail.mail']
                values = {}
                values.update({'subject':'Warning Email: ' + str(sendingData[0]['std_name']) + ' ,Payment Overdue'})
                
                if f.student_id.father_email:
                    recipientData.append(f.student_id.father_email)
                if f.student_id.mother_email:
                    recipientData.append(f.student_id.mother_email)
                if f.student_id.legal_guardian != 'father_is_legal_guardian':
                    if f.student_id.guardian_email:
                        recipientData.append(f.student_id.guardian_email)
                        
                print("reciepite daa finally....",recipientData)
                values.update({'email_to': ','.join(recipientData)})
                values.update({'body_html': body_html})
                values.update({'body': body_html})
                msg_id = mail_pool.create(values)
                try:
                    if msg_id:
                        msg_id.send()
            
                except Exception as e:
                    raise ValidationError(e)
        
        return
    
    
    
    
    def compute_name(self):
        for stfee in self:
            stfee.name = stfee.fee_policy_line_id.name
        return
    
    def get_final_applied_fee(self):
        for stfee in self:
            discounts = stfee.sibling_disc +stfee.emp_chil_disc + stfee.cash_discount
            stfee.applied_fee = stfee.total_amount - discounts 
        return
    
    def find_is_overdue(self):
        for stfee in self:
            today = date.today()
            if stfee.status =='unpaid':
                if str(today) > str(stfee.due_date):
                    stfee.is_overdue = True
                elif str(today) <= str(stfee.due_date):
                    stfee.is_overdue = False
            elif stfee.status =='paid':
               stfee.is_overdue = False
        return
    
    def call_fee_payment_wizard(self):
        std_fee_ids = self.env['student.fee'].search([('id', '=', self.id),('status', '=', 'unpaid')])
        wiz_lines = [(0, 0, {'student_id':std_fee_ids.student_id.id, 'std_fee_id': std_fee_ids.id , 'status':'unpaid','payment_date':None ,'applied_fee':std_fee_ids.applied_fee, 'due_date': std_fee_ids.due_date,'is_overdue':std_fee_ids.is_overdue})]
        wiz = self.env['student.fee.payment.wizard'].create({'mode':'pay_student_fee','operation_type':'single_record','installment_id': self.id, 'student_fee_ids': wiz_lines})
            
        if std_fee_ids:
            form_id = self.env.ref('sms_core.view_student_fee_payment_wizard', False)
            return {
            'name': 'Pay Student Fee',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'student.fee.payment.wizard',
            'view_id'   : form_id.id,
            'type': 'ir.actions.act_window',
            'target': 'new',
            'res_id': wiz.id,
            'context'   :{
                'default_installment_id':self.fee_policy_line_id.id,
                          }
            }
            
            
    def pay_student_fee_cm(self,student_fee_ids):
        """
        Central method that is called by wizard and cron job 
        Will set a meeting with client wahter needed a cron job for payment of student 
        fee or not, or it is already done by the payment wizard. may be we dont need cron job--shahid 27 june
        """
        for stdfee in student_fee_ids:
            fees =self.env['student.fee'].browse(stdfee['std_fee_id'])
            fees.write({'status':'paid','payment_date':stdfee['payment_date']})
            if fees.student_id:
                fees.student_id.message_post(body='Fee Paid for '+str(fees.student_id.full_name)+'.'+str(fees.name))
        return 
            
    
    def student_fee_reports_cm(self,date_from,date_to,student_ids=False,status=False):
        """
        This is Main central method that returns student fee details,
        Created by Sohail 23-June-2021
        
        Called by
        1) fee collection dues report
        """
        print("student ids...",student_ids)
        print("status...",status)
        std_result = self.env['student.fee'].search([('student_id', 'in', student_ids),('due_date', '>=', date_from),('due_date', '<=', date_to),('status', 'in', status)])
        mydict = {'total_amount': '','discount':'','net_amount':'','detail_dict':''}
        result = []
        result2 = []
        total_amt = 0
        total_disc = 0
        total_net_amt = 0
        for std in std_result:
            total_amt = total_amt + std.total_amount
            total_disc = total_disc + std.sibling_disc + std.emp_chil_disc + std.cash_discount
            total_net_amt = total_net_amt + std.applied_fee
            
            fee_records = {'std_name':'','fee_name':'','fee_date':'', 'due_date':'', 'total_amount':'', 'child_disc':'', 'cash_disc':'', 'applied_fee':'', 'payment_date':'', 'status':''}
            
            if std.student_id.state != 'Admitted':
                std_name = str(std.student_id.full_name)+"*"
            else:
                std_name = str(std.student_id.full_name)
                
            fee_records['std_name'] = std.student_id.full_name
            fee_records['fee_name'] = std.name
            fee_records['fee_date'] = str(std.fee_date)
            fee_records['due_date'] = str(std.due_date)
            fee_records['total_amount'] = std.total_amount
            fee_records['child_disc'] = std.sibling_disc + std.emp_chil_disc + std.cash_discount #combined all 3 disocunts types
            fee_records['cash_disc'] = std.cash_discount
            fee_records['applied_fee'] = std.applied_fee
            fee_records['payment_date'] = std.payment_date
            fee_records['status'] = std.status
            
            result2.append(fee_records)
        mydict['total_amount'] = total_amt
        mydict['discount'] = total_disc
        mydict['net_amount'] = total_net_amt
        mydict['detail_dict'] = result2
        result.append(mydict)
        return result
    
    
    
    name = fields.Char(string = 'Fee',compute='compute_name')
    student_id = fields.Many2one('academic.student', string="Student", required=True)
    fee_type = fields.Selection([('semester_fee', 'Semester Fee'), ('uniform_fee', 'Uniform Fee'),('books_fee', 'Books Fee'),('activities_fee', 'Activities Fee')], string='Fee Type', related="fee_policy_line_id.fee_type",tracking=True)
    fee_date = fields.Date('Fee Date', required=True, tracking=True)
    due_date = fields.Date('Due Date',  tracking=True)
    warning_date = fields.Date('Warning Date',tracking=True)
    total_amount = fields.Float(string = 'Fee',default=0.0, required=True, tracking=True)
    emp_chil_disc = fields.Float(string = 'Emp Child Dis',default=0.0,tracking=True)
    sibling_disc = fields.Float(string = 'Sibl Dis',default=0.0,tracking=True)
    cash_discount = fields.Float('Discount',tracking=True)
    applied_fee = fields.Float(string='Fee Applied', compute='get_final_applied_fee')
    status = fields.Selection([('unpaid', 'Unpaid'),('paid', 'Paid'), ('cancelled', 'Cancelled')], string='Status',tracking=True)
    payment_date = fields.Date('Payment Date',tracking=True)
    fee_policy_id = fields.Many2one('fee.policy', string="Fee Policy")
    fee_policy_line_id = fields.Many2one('fee.policy.line', string="Fee Policy Line")
    is_overdue = fields.Boolean(string ='Overdue',compute='find_is_overdue')
    serial_number = fields.Char('Serial Number')

    @api.model_create_multi
    def create(self, vals_lst):
        """
        Overridden create() method to set the sequence on the student fee
        ------------------------------------------------------------------
        @param vals_lst: A list of dictionary containing fields and values
        @return: A newly created recordset.
        """
        sequ = self.env.ref('sms_core.sequence_student_fee')
        for vals in vals_lst:
            vals.update({
                'serial_number': sequ.next_by_id()
            })
        return super(StudentFee, self).create(vals_lst)

    def print_report(self):
        data = {
            'ids': self.ids,
            'model': 'student.fee'
        }
        return self.env.ref('sms_core.action_student_fee_report_pdf').report_action(self, data=data)
