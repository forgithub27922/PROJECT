# -*- coding: utf-8 -*-
from odoo import models, fields, api,_
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression
import requests, json
from datetime import datetime, timedelta
from datetime import datetime
from datetime import date
from _ast import Try
from email.policy import default
from odoo.addons.test_convert.tests.test_env import field
import string
# from doc._extensions.autojsdoc.parser.parser import _name

class SmsCore(models.Model):
    
    _name = 'student.admission.form'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Student Admission Form'
    _order = 'date_of_apply desc'
    
#     def unlink(self):
#         raise UserError(_('Deletion not allowed,use the (Cancel) option instead'))
#            
#         return 
    
    def action_get_hr_attachment_view(self):
        res = self.env['ir.actions.act_window'].for_xml_id('base', 'action_attachment')
        res['domain'] = [('res_model', '=', 'student.admission.form'), ('res_id', 'in', self.ids)]
        res['context'] = {'default_res_model': 'student.admission.form', 'default_res_id': self.id}
        return res
    
    def _compute_attachment_docs(self):
        for emp in self:
            attachment_data = emp.env['ir.attachment'].search([('res_model', '=', 'student.admission.form'), ('res_id', 'in', emp.ids)])
            emp.attachment_docs = len(attachment_data)
    
    def print_report(self):
        data = {}
        data['form'] = self.read(['id'])[0]
        return self.env.ref('sms_core.action_std_admission_biodata_report').report_action(self, data=data, config=False)
    
    def set_as_pending_for_interview(self):
        try:
            sendingData = []
            recipientData = []
            today = datetime.now()
            current_month = today.strftime("%m")
            current_year = today.strftime("%Y")
            admission_id = self.env['student.admission.form'].search([('id', '=', self.id)])
            
            if admission_id.state == 'in_review':
                info = {
                    "name": admission_id['full_name'] if admission_id['full_name'] else '',
                }
                sendingData.append(info)

#             managers = self.env['res.users'].search([('groups_id', '=', 'Employees / Manager'), ('active', '=', True)])
#             recipientData = [str(i.email) for i in managers if type(i.email) is not bool]
            print(recipientData)
            if len(sendingData) > 0:
                print("Sending date", sendingData)
                body_html = """
                    <div><br/>
                    
                    <strong>Application No:</strong>""" + str(self.application_no or'--') + """<br/><br/>
                    <p>We are glad to inform you that your application for <strong> """ + str(sendingData[0]['name']) + """ </strong>, has
                    been selected to move to the next stage in the application process which is the
                     <strong>Interview </strong>. Kindly expect a phone call in the coming days. In case of no answer, 2
                    more attempts will be made, otherwise the application will be considered
                    Cancelled.
                    <br/><br/>Thank You
                    Thank You
                    </p>
                    </div>
                    """ 
                mail_pool = self.env['mail.mail']
                values = {}
                values.update({'subject':'Admission:' + str(sendingData[0]['name']) + ',Interview'})
                if admission_id.father_email:
                    recipientData.append(admission_id.father_email)
                if admission_id.mother_email:
                    recipientData.append(admission_id.mother_email)
                if admission_id.legal_guardian != 'father_is_legal_guardian':
                    if admission_id.guardian_email:
                        recipientData.append(admission_id.guardian_email)

                print("reciepite daa finally....",recipientData)
                values.update({'email_to': ','.join(recipientData)})
                values.update({'body_html': body_html})
                values.update({'body': body_html})
                msg_id = mail_pool.create(values)
                if msg_id:
                    msg_id.send()
                self.state = 'interview'
            
        except Exception as e:
            raise ValidationError(e)
    
        
    def set_as_pending_for_documents(self):
        
        try:
            sendingData = []
            recipientData = []
            today = datetime.now()
            current_month = today.strftime("%m")
            current_year = today.strftime("%Y")
            admission_id = self.env['student.admission.form'].search([('id', '=', self.id)])
            if admission_id.state == 'interview':
                info = {
                    "name": admission_id['full_name'] if admission_id['full_name'] else '',
                }
                sendingData.append(info)
#             managers = self.env['res.users'].search([('groups_id', '=', 'Employees / Manager'), ('active', '=', True)])
#             recipientData = [str(i.email) for i in managers if type(i.email) is not bool]
            print(recipientData)
            if len(sendingData) > 0:
                print("Sending date", sendingData)
                body_html = """
                    <div><br/>
                    <strong>Application No:</strong>""" + str(self.application_no or'--') + """<br/><br/>
                    <p>We are glad to inform you that your application for ,.<strong>""" + str(sendingData[0]['name']) + """,</strong> has
                    been selected to move to the next stage in the application process which is
                    <strong>Submitting the legal documents</strong>.
                    <br/><br/>Thank You
                    </p>
                    </div>
                    """ 
                print("Sending date after body", sendingData)
                mail_pool = self.env['mail.mail']
                
                if admission_id.father_email:
                    recipientData.append(admission_id.father_email)
                if admission_id.mother_email:
                    recipientData.append(admission_id.mother_email)
                if admission_id.legal_guardian != 'father_is_legal_guardian':
                    if admission_id.guardian_email:
                        recipientData.append(admission_id.guardian_email)
                values = {}
                values.update({'subject':'Admission:' + str(sendingData[0]['name']) + ',Document Submission'})
                values.update({'email_to': ','.join(recipientData)})
                values.update({'body_html': body_html})
                values.update({'body': body_html})
                msg_id = mail_pool.create(values)
                if msg_id:
                    msg_id.send()
                self.state = 'documentation'
            
        except Exception as e:
            raise ValidationError(e)
    
    def set_as_pending_for_payment(self):
        try:
            sendingData = []
            recipientData = []
            today = datetime.now()
            current_month = today.strftime("%m")
            current_year = today.strftime("%Y")
            admission_id = self.env['student.admission.form'].search([('id', '=', self.id)])
            if admission_id.state == 'documentation':
                info = {
                    "name": admission_id['full_name'] if admission_id['full_name'] else '',
                    'bank_name':'Bank Al Habib',
                    'branch_code':'02231',
                    'account_title':'School Account Title',
                    'account_no':'1234456777'
                }
                sendingData.append(info)
#             managers = self.env['res.users'].search([('groups_id', '=', 'Employees / Manager'), ('active', '=', True)])
#             recipientData = [str(i.email) for i in managers if type(i.email) is not bool]
            print(recipientData)
            if len(sendingData) > 0:
                print("Sending date", sendingData)
                body_html = """
                    <div>
                    <strong>Application No:</strong>""" + str(self.application_no or '--') + """<br/><br/>
                    <p>We are glad to inform you that the application process for """ + str(sendingData[0]['name']) + """  is 
                    successfully completed, and we are very excited to have """ + str(sendingData[0]['name']) + """ joining us. 
                    To finalize the admission, a payment of <strong>USD 120/</strong> should be transferred to our bank 
                    account (details below) within a period no longer than <strong> 10 JUN,2021</strong>. 
                    
                    Thanks and have a wonderful year.
                     </p><br/>
                    Bank details:
                    <br/> 
                    <center><table style="width:80%;border-collapse: collapse;border: 1px solid black;float:center">
                    <tr>
                    <td style=\"border: 1px solid black;border-collapse: collapse;\"><strong>Transfer Reference:</strong></td>
                    <td style=\"text-align: center;border: 1px solid black;border-collapse: collapse;\">""" + str(self.application_no or '--') + """ / """ + str(sendingData[0]['name']) + """</td>
                    <td style=\"border: 1px solid black;border-collapse: collapse;\"><strong>Invoice No:</strong></td>
                    <td style=\"text-align: center;border: 1px solid black;border-collapse: collapse;\">""" + str('INV0002') + """ / </td>
                    <td style=\"border: 1px solid black;border-collapse: collapse;\"><strong>Bank:</strong></td><td>""" + str(sendingData[0]['bank_name']) + """</td>
                    
                    </tr>
                    <tr>
                    <td style=\"border: 1px solid black;border-collapse: collapse;\"><strong>Account Title:</strong></td>
                    <td style=\"text-align: center;border: 1px solid black;border-collapse: collapse;\">""" + str(sendingData[0]['account_title']) + """</td>
                    <td style=\"border: 1px solid black;border-collapse: collapse;\"><strong>Account No:</strong></td>
                    <td style=\"text-align: center;border: 1px solid black;border-collapse: collapse;\">""" + str(sendingData[0]['account_no']) + """</td>
                    <td style=\"border: 1px solid black;border-collapse: collapse;\"><strong>Branch Code:</strong></td>
                    <td style=\"text-align: center;border: 1px solid black;border-collapse: collapse;\">""" + str(sendingData[0]['branch_code']) + """</td>
                    </tr>
                    <tr>
                    <td style=\" text-align: center;\"><h2>Amount:</h2></td>
                    <td style=\"text-align: center;border: 1px solid black;border-collapse: collapse;\"><h2>""" + str('USD 120') + """</h2></td>
                    <td style=\" text-align: center;\"><h2>Due Date:</h2></td>
                    <td style=\"text-align: center;border: 1px solid black;border-collapse: collapse;\"><h2>""" + str('10 JUN 2021') + """</h2></td>
                    </tr>
                    </table>
                   </center>
                    </div>
                    
                    <br/>
                    """ 
                mail_pool = self.env['mail.mail']
                if admission_id.father_email:
                    recipientData.append(admission_id.father_email)
                if admission_id.mother_email:
                    recipientData.append(admission_id.mother_email)
                if admission_id.legal_guardian != 'father_is_legal_guardian':
                    if admission_id.guardian_email:
                        recipientData.append(admission_id.guardian_email)
                values = {}
                values.update({'subject':'Admission:' + str(sendingData[0]['name']) + ' Make Payment'})
                values.update({'email_to': ','.join(recipientData)})
                values.update({'body_html': body_html})
                values.update({'body': body_html})
                msg_id = mail_pool.create(values)
                if msg_id:
                    msg_id.send()
                self.state = 'payment'
                
            
        except Exception as e:
            raise ValidationError(e)
        
    def cancel_application(self):
#         self.admission_date = datetime.today()
        try:
            sendingData = []
            recipientData = []
            today = datetime.now()
            current_month = today.strftime("%m")
            current_year = today.strftime("%Y")
            admission_id = self.env['student.admission.form'].search([('id', '=', self.id)])
            if admission_id.state in ('interview', 'documentation', 'payment'):
                info = {
                    "name": admission_id['full_name'] if admission_id['full_name'] else '',
                }
                sendingData.append(info)
#             managers = self.env['res.users'].search([('groups_id', '=', 'Employees / Manager'), ('active', '=', True)])
#             recipientData = [str(i.email) for i in managers if type(i.email) is not bool]
            print(recipientData)
            if len(sendingData) > 0:
                print("Sending data", sendingData)
                body_html = """
                    <div>
                    <p>We are sorry to inform you that the application process for """ + str(sendingData[0]['name']) + """ has 
                    been cancelled as we received no response from your side. Thanks for considering us and we hope to see 
                    you and """ + str(sendingData[0]['name']) + """ again soon. 
                    </p>
                    </div>
                    """ 
                print("Sending data after body", sendingData)
                mail_pool = self.env['mail.mail']
                if admission_id.father_email:
                    recipientData.append(admission_id.father_email)
                if admission_id.mother_email:
                    recipientData.append(admission_id.mother_email)
                if admission_id.legal_guardian != 'father_is_legal_guardian':
                    if admission_id.guardian_email:
                        recipientData.append(admission_id.guardian_email)
                values = {}
                values.update({'subject': 'Admission: Admission Email '})
                values.update({'email_to': ','.join(recipientData)})
                values.update({'body_html': body_html})
                values.update({'body': body_html})
                msg_id = mail_pool.create(values)
                if msg_id:
                    msg_id.send()
                self.state = 'cancelled'
                self.date_of_reject_cancel = datetime.now()
                self.rejected_by = self._uid
            
        except Exception as e:
            raise ValidationError(e)
        
    @api.onchange('legal_guardian')
    def check_legal_guardian_onchange(self):
        if self.legal_guardian == 'father_is_legal_guardian':
            if self.father_is_absent:
                self.legal_guardian = None
                
        elif self.legal_guardian == 'mother_is_legal_guardian':
            if self.mother_is_absent:
                self.legal_guardian = None
        if self.father_is_absent and self.mother_is_absent:
           self.legal_guardian = 'other' 
            
    @api.onchange('father_is_absent','mother_is_absent')
    def check_parents_absent_onchange(self):
        if self.father_is_absent: 
            if self.legal_guardian == 'father_is_legal_guardian':
                self.legal_guardian = None
                return
        if self.mother_is_absent: 
            if self.legal_guardian == 'mother_is_legal_guardian':
                self.legal_guardian = None
                return
        if self.mother_is_absent and self.father_is_absent: 
#             if self.legal_guardian == None:
            self.legal_guardian = 'other'
            return
    
    def _compute_student_name(self):
        for rec in self:
            rec.name = str(rec.first_name)+' '+str(rec.middle_name)+' '+str(rec.second_middle_name)+' '+str(rec.last_name) or ''
    # changes for code pushing
    # child fields:
    name = fields.Char('Student Name', compute='_compute_student_name')
    application_no = fields.Char('Application No')
    full_name = fields.Char('Full Name', tracking=True)
    first_name = fields.Char('First Name', required=True, tracking=True)
    middle_name = fields.Char('Middle Name')
    second_middle_name = fields.Char('Second Middle Name')
    last_name = fields.Char('Last Name', tracking=True)
    
    first_name_arabic = fields.Char('First Name Arabic', required=True, tracking=True)
    middle_name_arabic = fields.Char('Middle Name Arabic')
    second_middle_name_arabic = fields.Char('Second Middle Name Arabic')
    last_name_arabic = fields.Char('Last Name Arabic', tracking=True)
    
    full_name_arabic = fields.Char('Full Name Arabic')
    national_id = fields.Char('National ID', tracking=True)
    passport_id = fields.Char('Passport No', tracking=True)
    nationality = fields.Many2one('res.country', string='Nationality', tracking=True)
    birth_date = fields.Date('Date of Birth', tracking=True)
    birth_place = fields.Char('Birth Place')
    city = fields.Char('City')
    address = fields.Text('Address')
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('other', 'Other')], default='male', required=True, string='Gender')
    religion = fields.Selection([('muslim', 'Muslim'), ('non_muslim', 'Non Muslim')], default='muslim', string='Religion')
    student_image  = fields.Binary(string = 'Image',store=True,attachment=True)#application form
    attachment_docs = fields.Integer(compute='_compute_attachment_docs', string='Number of Attachments')
    # education = 
    application_for = fields.Selection([('american', 'American'), ('national', 'National'), ('ig', 'IG')], string='Application For')
    school_id = fields.Many2one('schools.list', string='Admitted to School', tracking=True)
    class_id = fields.Many2one('school.class', string='Admitted to Grade', tracking=True)
    school_name = fields.Char('School')
    class_grade = fields.Char('Grade')
    prevous_school = fields.Char('Previous School')
    primary_language = fields.Char('Primary Language')
    second_language = fields.Char('Second Language')
    sibing_status = fields.Selection([('no_siblings', 'No Siblings'),('has_brothers_sisters', 'Brothers/Sisters in School'), ('staff_child', 'Staff Child')], default='no_siblings', string='Sibling Status')
    state = fields.Selection([('in_review', 'In Review'), ('interview', 'Interview'), ('documentation', 'Documentation'), ('payment', 'Payment'), ('rejected', 'Rejected'), ('cancelled', 'Cancelled'), ('admitted', 'Admitted'),('undecided','Undecided')], 'State', default='in_review')
    date_of_apply = fields.Datetime('Date of Apply', default=datetime.now())
    date_of_admission = fields.Datetime('Date of Confirmation')
    date_of_reject_cancel = fields.Datetime('Date Reject Cancel')
    admitted_by = fields.Many2one('res.users', string='Confirmed By')
    rejected_by = fields.Many2one('res.users', string='Rejected By')
    # Fields (Father) 
    father_full_name = fields.Char('Father Full Name', tracking=True)
    father_full_name_arabic = fields.Char('Father Full Name Arabic')
    father_national_id = fields.Char('National ID', tracking=True)
    father_nationality = fields.Many2one('res.country', string='Nationality')
    father_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], string='Marital Status')
    father_degree_education = fields.Char('Education')
    father_employment = fields.Char('Employment')
    father_employer_location = fields.Char('Employment Location')
    father_landline_number = fields.Char('Home Phone')
    father_land_line_no = fields.Char('Work Phone')
    father_mobile_no = fields.Char('Mobile Number', tracking=True)
    father_email = fields.Char(string='Email')
    father_is_absent = fields.Boolean('Father is Absent')
    
    # Fields(Mother)
    mother_full_name = fields.Char('Mother Full Name', tracking=True)
    mother_full_name_arabic = fields.Char('Mother Full Name Arabic')
    mother_national_id = fields.Char('National ID', tracking=True)
    mother_nationality = fields.Many2one('res.country', string='Nationality')
    mother_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], string='Marital Status')
    mother_degree_education = fields.Char('Education')
    mother_employment = fields.Char('Employment')
    mother_employer_location = fields.Char('Employment Location')
    mother_landline_number = fields.Char('Home Phone')
    mother_land_line_no = fields.Char('Work Phone')
    mother_mobile_no = fields.Char('Mobile Number', tracking=True)
    mother_email = fields.Char(string='Email')
    mother_is_absent = fields.Boolean('Mother is Absent')
    
    # Guardian Fields:
    legal_guardian = fields.Selection([('father_is_legal_guardian', 'Father is the legal guardian'), ('mother_is_legal_guardian', 'Mother is the legal guardian'), ('other', 'Other')], string='Legal Guardian')
    guardian_full_name = fields.Char('Guardian Full Name', tracking=True)
    guardian_full_name_arabic = fields.Char('Guardian Full Name Arabic')
    guardian_national_id = fields.Char('National ID', tracking=True)
    relation_to_child = fields.Char('Relation to The Child')
    guardian_nationality = fields.Many2one('res.country', string='Nationality')
    guardian_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], string='Marital Status')
    guardian_degree_education = fields.Char('Education')
    guardian_employment = fields.Char('Employment')
    guardian_employeer_location = fields.Char('Employment Location')
    guardian_landline_number = fields.Char('Home Phone')
    guardian_land_line_no = fields.Char('Work Phone')
    guardian_mobile_no = fields.Char('Mobile Number', tracking=True)
    guardian_email = fields.Char(string='Email')
    # Moodle Fields:
    md_parent_username = fields.Char('LMS Parent User Name')
    md_password = fields.Char('LMS Password')
    md_username = fields.Char('LMS User Name')
    mooddle_id = fields.Char('LMS ID', tracking=True)

    @api.constrains('national_id', 'passport_id')
    def check_national_id_passport_id(self):
        """
        This method will check national id or passport id fill or not
        -------------------------------------------------------------
        @param self: object pointer
        """
        for student in self:
            if not student.national_id and not student.passport_id:
                raise ValidationError(_('Please Fill Either National ID or Passport No'))

    @api.model
    def create(self, vals):
        ex_dict ={"national_id":'',"std_name":'',"status":'',}
        if vals.get('national_id'):
            exist = self.search([('national_id', '=',vals['national_id'])])
            if exist:
                exist = exist[0]
                ex_dict['national_id'] = exist.national_id
                ex_dict['std_name'] = exist.full_name
                ex_dict['status'] = exist.state
                return ex_dict
#         appl_no = self.env['ir.sequence'].next_by_code('student.admission.form')
        count = self.env['student.admission.form'].search([])
        t_conut = len(count)
        appl_no ='APPL'+str(t_conut).zfill(6)
        vals.update({'application_no':appl_no})
        if 'mother_is_guardian' in vals:
            if vals['mother_is_guardian'] == 'on':
                vals['legal_guardian'] = 'mother_is_legal_guardian'
                vals.pop("mother_is_guardian") 
        elif 'father_is_guardian' in vals:
            if vals['father_is_guardian'] == 'on':
                vals['legal_guardian'] = 'father_is_legal_guardian' 
                vals.pop("father_is_guardian")
        else:
            if 'father_full_name' in vals:
                vals['legal_guardian'] = 'father_is_legal_guardian'
            if 'mother_full_name' in vals:
                vals['legal_guardian'] = 'mother_is_legal_guardian'
            if 'father_full_name' not in vals and 'mother_full_name' not in vals:
                vals['legal_guardian'] = 'other'
        
        print("vals before create::",vals)
        smscore_obj = super(SmsCore, self).create(vals)
        return smscore_obj
        
#     def write(self, vals):
#         re = super(SmsCore, self).write(vals)
#         res = self.env['student.admission.form'].browse(self.id)
#         full_name = res.full_name.split()
#         first_name = full_name[0]
#         last_name =' '
#         if len(full_name) >1:
#              last_name = full_name[1]
#         print("-----------full name------------",last_name,first_name)
#         parameters = '&users[0][id]=' + str(res.mooddle_id) + '&users[0][username]=' + str(res.md_username) + '&users[0][firstname]=' + str(first_name)+ '&users[0][lastname]=' + str(last_name)+ '&users[0][password]=' + str(res.md_password)   
#         moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_user_update_users&moodlewsrestformat=json'
#         head_params = {'wsfunction':'core_user_update_users', 'moodlewsrestformat':'json'}
#         response = requests.get(moodle_url, params=head_params)
#         response = response.json()
#         if response:
#             return res
    
class Followers(models.Model):
   _inherit = 'mail.followers'
   @api.model
   def create(self, vals):
        if 'res_model' in vals and 'res_id' in vals and 'partner_id' in vals:
            dups = self.env['mail.followers'].search([('res_model', '=',vals.get('res_model')),
                                           ('res_id', '=', vals.get('res_id')),
                                           ('partner_id', '=', vals.get('partner_id'))])
            if len(dups):
                for p in dups:
                    p.unlink()
        return super(Followers, self).create(vals)

class SchoolsList(models.Model): 
    
    _name = 'schools.list'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'schools.list'
    
    _sql_constraints = [('name_uniq', 'unique (name)', "School with same name already exists !")]
    
    def unlink(self):
        res = self.sync_erp_lms('class.section')
        print("this is the school unlink method",res)
#         if self.active == True:
#         raise UserError(_('Deletion are not allowed on ERP.'))
#         else:
#             rec = super(SchoolsList, self).unlink()    
#         return rec
        return
    def menu_item_sync_erp_lms(self):
        print("menu_item_sync_erp_lms")
        tb_ls =  ['class.section','schools.list']
        for f in tb_ls:
            res = self.sync_erp_lms(f,'called from cron job')
            print("This is the reponse of menu item sync erp lms",res)
    
    school_id = fields.Integer('School ID')
    name = fields.Char('School Name', required=True, tracking=True)
    domain_name = fields.Char('Domain Name', required=True, tracking=True,default = 'gmail.com')
    school_type = fields.Selection([('pre_school', 'Pre School'), ('primary', 'Primary'), ('secondary', 'Secondary'), ('higher_secondary', 'Higher Secondary')],default='pre_school', string='School Type')
    school_description = fields.Text('Description')
    moodle_id = fields.Char('Moodle ID', tracking=True)
    active = fields.Boolean('Active', tracking=True,default=True)
    school_class_ids = fields.One2many('school.class', 'school_id')
    school_students_ids = fields.One2many('academic.student', 'school_id', string='Students')
    lms_status = fields.Selection([('synced', 'Synced'), ('not_synced', 'Not Synced'), ('in_active', 'Inactive'), ('deleted', 'Deleted')], string='Lms Status')
    
    def sync_erp_lms(self,table_md,reqt_source):
        if table_md == 'schools.list':
            lms_school_lst =[]
            lms_class_lst = []
            parameters = ''
            moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_course_get_categories&moodlewsrestformat=json'
            head_params = {'wsfunction':'core_course_get_categories', 'moodlewsrestformat':'json'}
            response = requests.get(moodle_url, params=head_params)
            response = response.json()
            print("this is the get category response",response)
            for f in response:
                print("response for each",f['name'])
                if f['parent'] == 0:
                    print("no patent")
                    lms_school_lst.append(f['id'])
                    rec_exist = self.env['schools.list'].search([('moodle_id','=',f['id'])])
                    if not rec_exist:
                        self.env['schools.list'].create({
                        'name': f['name'],
                        'school_description': f['name'],
                        'moodle_id':f['id'],
                        'lms_status': 'synced'})
                    else:
                        rec_exist.name = f['name']
                else:
                    print("child")
                    lms_class_lst.append(f['id'])
                    cls_exist = self.env['school.class'].search([('mooddle_id','=',f['id'])])
                    if not cls_exist:
                        parent_rec = self.env['schools.list'].search([('moodle_id','=',f['parent'])])
                        self.env['school.class'].create({
                        'name': f['name'],
                        'desc': f['name'],
                        'mooddle_id':f['id'],
                        'school_id':parent_rec.id,
                        'cls_lms_status': 'synced'})
                    else:
                        cls_exist.name = f['name']
            not_exist = self.env['schools.list'].search([('moodle_id','not in',lms_school_lst)])      
            for t in not_exist:
                t.lms_status = 'deleted'
            cls_not_exist = self.env['school.class'].search([('mooddle_id','not in',lms_school_lst)])      
            for t in cls_not_exist:
                t.cls_lms_status = 'deleted'
        elif table_md == 'class.section':
            lms_cls_sec_lst =[]
            parameters = ''
            moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_cohort_get_cohorts&moodlewsrestformat=json'
            head_params = {'wsfunction':'core_cohort_get_cohorts', 'moodlewsrestformat':'json'}
            response = requests.get(moodle_url, params=head_params)
            response = response.json()
            print("response will print here",response)
            for f in response:
                if f['name']:
                    lms_cls_sec_lst.append(f['id'])
                    sec_rec_exist = self.env['class.section'].search([('mooddle_id','=',f['id'])])
                    print("this is the sec_rec_exist",sec_rec_exist)
                    if not sec_rec_exist:
                        sec_rec_exist.create({'name': f['name'],
                                          'mooddle_id': f['id'],
                                          'cls_sec_lms_status': 'synced'})
                    else:
                        sec_rec_exist.name = f['name']
            cls_sec_n_exist = self.env['class.section'].search([('mooddle_id','not in',lms_cls_sec_lst)])      
            for t in cls_sec_n_exist:
                t.cls_sec_lms_status = 'deleted'
        return
    
#     def display_lms_status(self):
#         if self.moodle_id == None:
#             self.lms_status = 'not_synced'
#         else:
#             self.lms_status = 'synced'
#         return

#     @api.model
#     def create(self, vals):
#         schools_obj = super(SchoolsList, self).create(vals)
#         try:
#             parameters = '&categories[0][name]=' + str(vals['name']) + '&categories[0][parent]=' + str(0) + '&categories[0][description]=' + str(vals['school_description'])
#             moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_course_create_categories&moodlewsrestformat=json'
#             head_params = {'wsfunction':'core_course_create_categories', 'moodlewsrestformat':'json'}
#             response = requests.get(moodle_url, params=head_params)
#             response = response.json()
#             if response:
#                 response = response[0]
#             if 'id' in response:
#                 schools_obj.moodle_id = response['id']
#         except:
#             raise UserError(_('Category! Record not created on lms contact your system administrator'))
#         return schools_obj
    
    
    
    
    
    def cron_sync_erp_lms(self):
        print("cron job is called for erp lms sync")
        tb_ls =  ['class.section','schools.list']
        for f in tb_ls:
            res = self.sync_erp_lms(f,'called from cron job')
            print("This is the reponse of cron sync erp lms",res)
            
    
class SchoolClass(models.Model):
    
    _name = 'school.class'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'school.class'
    
     
    name = fields.Char(string='Grade', required=True, tracking=True) 
    desc = fields.Char(string='Description')
    grading_policy = fields.Char(string='Grading Policy')  # it will be one2many with'sms.grading.policy'
    sequence = fields.Integer(string='Sequence No') 
    school_id = fields.Many2one('schools.list', strgin="School", require=True)
    courses_ids = fields.One2many('class.course', 'class_id', string="Courses")
    students_ids = fields.One2many('academic.student', 'class_id', string="Students")
    active = fields.Boolean('Active', default=True, tracking=True)
    mooddle_id = fields.Char('Moodle ID', tracking=True)
    cls_lms_status = fields.Selection([('synced', 'Synced'), ('not_synced', 'Not Synced'), ('in_active', 'Inactive'), ('deleted', 'Deleted')], string='Lms Status')
    def unlink(self):
        raise UserError(_('Deletion are not allowed on ERP.'))
    
    
    
    def sync_cohort_student_with_erp(self):
        print("sync_cohort_student_with_erp method is called")
        for i in self.env['class.section'].search([('sync','=',True)]):
            if True:
                parameters = '&cohortids[0]='+str(i.mooddle_id)
                moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_cohort_get_cohort_members&moodlewsrestformat=json'
                head_params = {'wsfunction':'core_cohort_get_cohort_members', 'moodlewsrestformat':'json'}
                response = requests.get(moodle_url, params=head_params)
                response = response.json()
                response = response[0]
                print("LMS response Cohorts",response)
                
                
                if 'userids' in response:
                    cohortid = response['cohortid']
                    class_id = self.env['class.section'].search([('mooddle_id','=',cohortid)])
                    erp_student = self.env['academic.student'].search([('class_section_id','=',class_id.id)])
                    
                    for s in erp_student:
                        s.class_section_id = None
                        
                        
                    for mod in response['userids']:
                        std_exist = self.env['academic.student'].search([('mooddle_id','=',mod)])
                        if std_exist:
                            std_exist.class_section_id = class_id.id
                        else:
                            adm_exist = self.env['academic.student'].search([('mooddle_id','=',mod)])
                            if not adm_exist:
                                parameters = '&criteria[0][key]=id&criteria[0][value]='+str(mod)
                                moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_user_get_users&moodlewsrestformat=json'
                                head_params = {'wsfunction':'core_user_get_users', 'moodlewsrestformat':'json'}
                                response = requests.get(moodle_url, params=head_params)
                                response = response.json()
                                
                                if 'users'in response:
                                    user_info = response['users'][0]
                                    rec  = self.env['student.admission.form'].create({
                                        'full_name':user_info['firstname'],
                                        'md_username':user_info['username'],
                                        'mooddle_id':user_info['id'],
                                        'national_id':user_info['id'],
                                        'class_id':class_id.grade_id.id,
                                        'school_id':class_id.grade_id.school_id.id,
                                        'state':'undecided',
                                        })
                                    print("result",rec)
            
#             except:
#                 raise UserError(_('Not sync with lms contact your system administrator'))
        return
    
    @api.model
    def create(self, vals):
        response = {'debuginfo':''}
        class_obj = super(SchoolClass, self).create(vals)
#         if class_obj:
#             school_moodle_id = class_obj.school_id.moodle_id
# #             if not school_moodle_id:
#                 raise UserError(_('LMS ID Not Found for School'+str(class_obj.school_id))
#             #old code to create class using moodle categories
#             parameters = '&categories[0][name]=' + str(vals['name']) + '&categories[0][parent]=' + str(school_moodle_id) + '&categories[0][description]=' + str(vals['desc'])
#             moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_course_create_categories&moodlewsrestformat=json'
#             head_params = {'wsfunction':'core_course_create_categories', 'moodlewsrestformat':'json'}
#                         
#             response = requests.get(moodle_url, params=head_params)
#             response = response.json()
#             print("response",response)
#             if response:
#                 response = response[0]
#             if 'errorcode' in response:
#                 raise UserError(_('%s') % (response['debuginfo']))
#             elif 'id' in response:
#                 class_obj.mooddle_id = response['id']
#             return class_obj
#         else:
        return
        

class ClassSection(models.Model):
    
    _name = 'class.section'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'class.section'
    
    
    @api.model
    def create(self, vals):
        if 'grade_id' in vals:
            
            if vals['grade_id']:
                _sql = """SELECT COALESCE(MAX(sequence_no),'0') FROM class_section
                              WHERE grade_id = """+str(vals['grade_id'])+ """ """
        else:
            _sql = """SELECT COALESCE(MAX(sequence_no),'0') FROM class_section """
              
        self.env.cr.execute(_sql)
        max_no = self.env.cr.fetchone()[0]
        print("No is +++++",max_no)
        vals['sequence_no'] = max_no + 1
        class_obj = super(ClassSection, self).create(vals)
        return class_obj
    
    def get_current_strength(self):
        
        for f in self:
            count = self.env['academic.student'].search([('class_section_id','=',f.id),('class_id','=',f.grade_id.id)])
            print("this is count ==== ",count)
            f.current_strength = len(count)
    
    name = fields.Char(string='Class', required=True, tracking=True)
    grade_id = fields.Many2one('school.class', string='Grade', tracking=True)
    sequence_no = fields.Integer(string='Sequence No')
    max_capacity = fields.Integer(string='Max Capacity', tracking=True,default="40")
    current_strength = fields.Integer(string='Current Strength', compute='get_current_strength')
    student_ids = fields.One2many('academic.student', 'class_section_id', string="Students")
    mooddle_id = fields.Char('Moodle ID', tracking=True)
    cls_sec_lms_status = fields.Selection([('synced', 'Synced'), ('not_synced', 'Not Synced'), ('in_active', 'Inactive'), ('deleted', 'Deleted')], string='Lms Status')
    sync = fields.Boolean('Sync')
#     def unlink(self):
#         raise UserError(_('Deletion are not allowed on ERP.'))
    
    #CODE COMMENTED DUE TO STRUCTURE CHANGES
#     def unlink(self):
#         try:
#             print("this is the deleted id",self.mooddle_id)
#             parameters = '&cohortids[0]='+str(self.mooddle_id)
#             moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_cohort_delete_cohorts&moodlewsrestformat=json'
#             head_params = {'wsfunction':'core_cohort_delete_cohorts', 'moodlewsrestformat':'json'}
#             response = requests.get(moodle_url, params=head_params)
#             response = response.json()
#             print("Cohort delete API Response",response)
#             if response == None:
#                 print("Cohort Deleted Successfully")
#         except:
#              raise UserError(_('Cohort! Record not Deleted on lms contact your system administrator'))
#         rec = super(ClassSection, self).unlink() 
#         return rec
    
#     @api.model
#     def create(self, vals):
#         class_obj = super(ClassSection, self).create(vals)
#         try:
#             parameters = '&cohorts[0][idnumber]='+str(class_obj.id)+\
#                  '&cohorts[0][categorytype][type]=system'+\
#                  '&cohorts[0][categorytype][value]='+str(class_obj.grade_id.mooddle_id)+\
#                  '&cohorts[0][name]='+str(class_obj.name)+\
#                  '&cohorts[0][descriptionformat]=1'+\
#                  '&cohorts[0][visible]=1'+\
#                  '&cohorts[0][description]='+str(class_obj.name)
#             moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_cohort_create_cohorts&moodlewsrestformat=json'
#             head_params = {'wsfunction':'core_cohort_create_cohorts', 'moodlewsrestformat':'json'}
#             response = requests.get(moodle_url, params=head_params)
#             response = response.json()
#             print("response--------",response)
#             if response:
#                 response = response[0]
#             if 'id' in response:
#                 class_obj.mooddle_id = response['id']
#         except:
#             raise UserError(_('Cohort! Record not created on lms contact your system administrator'))
#         return class_obj

#     def write(self, vals):
#         print("write method is called",vals)
#         res = super(ClassSection, self).write(vals)
#         class_obj = self.env['class.section'].browse(self.id)
#         try:
#             parameters = '&cohorts[0][id]='+str(class_obj.mooddle_id)+\
#                  '&cohorts[0][idnumber]='+str(class_obj.id)+\
#                  '&cohorts[0][categorytype][type]=system'+\
#                  '&cohorts[0][categorytype][value]='+str(class_obj.grade_id.mooddle_id)+\
#                  '&cohorts[0][name]='+str(class_obj.name)+\
#                  '&cohorts[0][descriptionformat]=1'+\
#                  '&cohorts[0][visible]=1'+\
#                  '&cohorts[0][description]='+str(class_obj.name)
#             moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_cohort_update_cohorts&moodlewsrestformat=json'
#             head_params = {'wsfunction':'core_cohort_update_cohorts', 'moodlewsrestformat':'json'}
#             response = requests.get(moodle_url, params=head_params)
#             response = response.json()
#             print("response----Updated---cohort-",response)
#         except:
#             raise UserError(_('Cohort! Record not Updated on lms contact your system administrator'))
#         return res



    
class CourseRepository(models.Model):
    
    _name = 'course.repository'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'course.repository'
    
    name = fields.Char(string='Course', required=True, tracking=True) 
    desc = fields.Char(string='Description')
    active = fields.Boolean('Active', default=True, tracking=True)
    sequence = fields.Integer(string='Sequence No')

class ClassCourses(models.Model):
    
    _name = 'class.course'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'class.course'
    
    name = fields.Many2one('course.repository', string='Course', required=True, tracking=True)
    class_id = fields.Many2one('school.class', string='Grade', required=True) 
    desc = fields.Char(string='Description')
    active = fields.Boolean('Active', tracking=True)
    mooddle_id = fields.Char('Moodle ID', tracking=True)
    
    
    @api.model
    def create(self, vals):
        response={'message':''}
        schools_obj = super(ClassCourses, self).create(vals)
        #the following code is commented on 12 jul by shahid due to the client requirements that classes, grades and 
        #schools will be crated from moodle side, and will fetched in odoo
        #when there is a need to uncomment this code, the try block should contain only the call to api
        #rest of the code should be outside of try block
#         try:
#             
#             parameters= '&courses[0][fullname]='+str(schools_obj.name.name)+'&courses[0][categoryid]='+str(int(schools_obj.class_id.mooddle_id))+'&courses[0][shortname]='+str(schools_obj.name.name+str(schools_obj.id))
#             moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246'+parameters+'&wsfunction=core_course_create_courses&moodlewsrestformat=json'
#             head_params = {'wsfunction':'core_course_create_courses', 'moodlewsrestformat':'json'}
#             response = requests.get(moodle_url, params=head_params)
#             response = response.json()
#             print("Response ClassCourses",response)
#             if response:
#                 if 'errorcode' in response:
#                     raise UserError(_('%s') % (response['message']))
#                 else:
#                     response = response[0]
#                     if 'id' in response:
#                         schools_obj.mooddle_id = response['id']
#                         return schools_obj
#         except:
#             print("This is the Exception point")
#             raise UserError(_('%s') % (response['message']))
        return

class AcademicStudent(models.Model):
    _name = "academic.student"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "academic.student"
    
    def change_student_class(self):
        rec_exist = self.env['student.class'].search([('student_id','=',self.id),('status','=','active')])
        print("check that rec exist ++++++ ", rec_exist)
        if self.state == 'admitted':
            if rec_exist:
                form_id = self.env.ref('sms_core.view_admit_student_school_wizard', False)
                return {
                'name': 'Update Student Class',
                'view_type': 'form',
                'view_mode': 'form',
                'res_model': 'admit.student.school.wizard',
                'view_id'   : form_id.id,
                'type': 'ir.actions.act_window',
                'target': 'new',
                'context'   :{
                    'default_line_rec_id':self.id,
                    'default_parent_id':self.id,
                              'default_school_id':rec_exist.class_id.school_id.id,
                              'default_class_grade_id': rec_exist.class_id.id,
                              'default_class_course_ids':rec_exist.class_id.courses_ids.ids,
                            'default_wizard_mode': 'academic_student'
                              }}
    
    
    def unlink(self):
        raise UserError(_('Student should not be deleted, use the option of withdrawal instead.'))
    
    def withdraw_student(self):
        std_class = self.env['student.class'].search([('student_id','=',self.id),('status','=','active')])
        for cls in std_class:
            cls.status = 'withdrawn'
        std_courses = self.env['student.courses'].search([('student_id','=',self.id),('course_status','=','active')])
        for course in std_courses:
            course.course_status = 'withdrawn'
        self.state = 'withdrawn'
        self.date_of_withdraw = datetime.today()  
        self.withdraw_by =  self._uid
        try:
            parameters = '&members[0][cohortid]='+str(std_class.class_id.mooddle_id)+\
                         '&members[0][userid]='+str(self.mooddle_id)
            moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_cohort_delete_cohort_members&moodlewsrestformat=json'
            head_params = {'wsfunction':'core_cohort_delete_cohort_members', 'moodlewsrestformat':'json'}
            response = requests.get(moodle_url, params=head_params)
            response = response.json()
            print("Delete cohort member",response)
        except:
            raise UserError(_('Record not deleted on lms contact your system administrator'))
        return
    
    
    def cron_deactive_lms(self):
        """
        This method is called, by a cron job to de-activate defaulter student on lms.
        """
        std_lst = []
        flg = 'in_active' 
        today_date = datetime.now().date()
        #FOR DEACTIVATION OF DEFAULTER STUDENTS
        std_fee = self.env['student.fee'].search([('is_overdue','=',True),('warning_date','<',today_date)])
        for f in std_fee:
            if f not in std_lst:
                std_lst.append(f.student_id.id)
                res = self.active_inactive_student(f.student_id,'Fee_defaulter',flg)
        #FOR ACTIVATION OF DEACTIVE STUDENTS    
        std_ids = self.env['academic.student'].search([('moodle_status','=','in_active'),('reason','=','Fee_defaulter')])   
        for std in std_ids:  
            for f in std.student_fee_ids:
                if not f.is_overdue:
                    flg = 'active'
                    res = self.active_inactive_student(f.student_id,'clear',flg)
                    continue
        return 
    
    
    def active_inactive_student(self,std_id,reason,flg):
        """
        This is central method called from cron jobs also from a wizrd, used to 
        activat and de-activate student from lms
        """
        password = 'in_active_123_@sync'
        std_id.reason = reason
        if flg =='in_active':
            std_id.moodle_status = 'in_active' 
            if reason =='Fee_defaulter': 
                recipientData = []
                body_html = """<div><br/><p>
                    The access to our EduSync learning management system has been temporarily
                    deactivated because a payment due date is reached. We apologize for the
                    inconvenience <br/> <br/>
                    Thank You.</p></div>""" 
                mail_pool = self.env['mail.mail']
                std_email =''
                if std_id.father_email:
                    std_email = std_id.father_email
                elif std_id.mother_email:
                    std_email = std_id.mother_email
                else :
                    std_email = std_id.guardian_email
                if not std_email:
                    raise UserError(_('Email address is missing.'))
                recipientData.append(std_email)
                values = {}
                values.update({'subject':'LMS Account Deactivated'})
                values.update({'email_to': ','.join(recipientData)})
                values.update({'body_html': body_html})
                values.update({'body': body_html})
                msg_id = mail_pool.create(values)
                if msg_id:
                    msg_id.send()
        else:
            password = std_id.md_password
            std_id.moodle_status = 'active'
        try:
            print("password",password)
            parameters = '&users[0][id]=' + str(std_id.mooddle_id) + '&users[0][password]=' + str(password)   
            moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_user_update_users&moodlewsrestformat=json'
            head_params = {'wsfunction':'core_user_update_users', 'moodlewsrestformat':'json'}
            response = requests.get(moodle_url, params=head_params)
            response = response.json()
            print("ACTIVE INACTIVE STUDENT METHOD UPDATE API RESPONSE",response)
        except:
            raise UserError(_('Password not updated on lms contact your system administrator'))
        return 


    def compute_student_unique_id(self):
        for std in self:
            std.student_id = 'STD'+str(std.id).zfill(5)
        return
    
    # child fields:
    def _compute_student_name(self):
        for std in self:
            std.name = str(std.first_name)+' '+str(std.middle_name)+' '+str(std.second_middle_name)+' '+str(std.last_name) or ''
    
    # child fields:
    # photo
    name = fields.Char('Student Name', compute='_compute_student_name')
    full_name = fields.Char('Full Name', tracking=True)
    first_name = fields.Char('First Name', required=True, tracking=True)
    middle_name = fields.Char('Middle Name')
    second_middle_name = fields.Char('Second Middle Name')
    last_name = fields.Char('Last Name', tracking=True)
    
    first_name_arabic = fields.Char('First Name Arabic', required=True, tracking=True)
    middle_name_arabic = fields.Char('Middle Name Arabic')
    second_middle_name_arabic = fields.Char('Second Middle Name Arabic')
    last_name_arabic = fields.Char('Last Name Arabic', tracking=True)
    
    student_image  = fields.Binary(string = 'Image',store=True,attachment=True)#academic.student table
    full_name_arabic = fields.Char('Full Name Arabic')
    student_id = fields.Char('Student ID', compute='compute_student_unique_id')
    national_id = fields.Char('National ID', tracking=True)
    passport_id = fields.Char('Passport No', tracking=True)
    nationality = fields.Many2one('res.country', string='Nationality', tracking=True)
    birth_date = fields.Date('Date of Birth', tracking=True)
    birth_place = fields.Char('Birth Place')
    city = fields.Char('City')
    address = fields.Text('Address')
    gender = fields.Selection([('male', 'Male'), ('female', 'Female'), ('other', 'Other')], default='male', required=True, string='Gender')
    religion = fields.Selection([('muslim', 'Muslim'), ('non_muslim', 'Non Muslim')], default='muslim', string='Religion')
    student_classes_ids = fields.One2many('student.class', 'student_id', string='Classes')
    student_courses_ids = fields.One2many('student.courses', 'student_id', string='Student Courses')
    student_fee_ids = fields.One2many('student.fee', 'student_id', string='Student Fee')
    
    # education = 
    admission_date = fields.Date('Admission Date')
    application_for = fields.Selection([('american', 'American'), ('national', 'National'), ('ig', 'IG')], string='Application For')
    class_id = fields.Many2one('school.class', string='Grade', tracking=True)
    class_section_id = fields.Many2one('class.section', string='Section', tracking=True)
    school_id = fields.Many2one('schools.list', related='class_id.school_id', string='School', tracking=True)
    prevous_school = fields.Char('Previous School')
    primary_language = fields.Char('Primary Language')
    second_language = fields.Char('Second Language')
    sibing_status = fields.Selection([('no_siblings', 'No Siblings'),('has_brothers_sisters', 'Brothers/Sisters in School'), ('staff_child', 'Staff Child')], default='no_siblings', string='Sibling Status')
    state = fields.Selection([('draft', 'Draft'), ('admitted', 'Admitted'), ('cancelled', 'Cancelled'),('inactive', 'Inactive'),('withdrawn', 'Withdrawn')], 'State', default='draft', tracking=True)
    date_of_apply = fields.Date('Admission Date', default=datetime.today())
    date_of_admission = fields.Datetime('Date of Admission')
    admitted_by = fields.Many2one('res.users', string='Admitted By')
    date_of_withdraw = fields.Datetime('Date Withdrawn')
    withdraw_by = fields.Many2one('res.users', string='Withdrawn By')
    
    family_id = fields.Many2one('student.parent.guardian.info', string="Family ID")
    
    # Fields (Father) 
    father_full_name = fields.Char('Father Full Name', related='family_id.father_full_name', tracking=True)
    father_full_name_arabic = fields.Char('Father Full Name Arabic', related='family_id.father_full_name_arabic')
    father_national_id = fields.Char('National ID', related='family_id.father_national_id', tracking=True)
    father_nationality = fields.Many2one('res.country', related='family_id.father_nationality', string='Nationality')
    father_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], related='family_id.father_marital_status', string='Marital Status')
    father_degree_education = fields.Char('Education', related='family_id.father_degree_education')
    father_employment = fields.Char('Employment', related='family_id.father_employment')
    father_employer_location = fields.Char('Employment Location', related='family_id.father_employer_location')
    father_landline_number = fields.Char('Home Phone', related='family_id.father_landline_number')
    father_land_line_no = fields.Char('Work Phone', related='family_id.father_land_line_no')
    father_mobile_no = fields.Char('Mobile Number', tracking=True)
    father_email = fields.Char(string='Email', related='family_id.father_email')
    father_is_absent = fields.Boolean('Father is Absent', related='family_id.father_is_absent')
    
    # Fields(Mother)
    mother_full_name = fields.Char('Mother Full Name', related='family_id.mother_full_name' , tracking=True)
    mother_full_name_arabic = fields.Char('Mother Full Name Arabic', related='family_id.mother_full_name_arabic')
    mother_national_id = fields.Char('National ID', related='family_id.mother_national_id' , tracking=True)
    mother_nationality = fields.Many2one('res.country', related='family_id.mother_nationality', string='Nationality')
    mother_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], related='family_id.mother_marital_status' , string='Marital Status')
    mother_degree_education = fields.Char('Education', related='family_id.mother_degree_education')
    mother_employment = fields.Char('Employment', related='family_id.mother_employment')
    mother_employer_location = fields.Char('Employment Location', related='family_id.mother_employer_location')
    mother_landline_number = fields.Char('Home Phone', related='family_id.mother_landline_number')
    mother_land_line_no = fields.Char('Work Phone', related='family_id.mother_land_line_no')
    mother_mobile_no = fields.Char('Mobile Number', tracking=True)
    mother_email = fields.Char(string='Email', related='family_id.mother_email')
    mother_is_absent = fields.Boolean('Mother is Absent', related='family_id.mother_is_absent')
    
    # Guardian Fields:
    legal_guardian = fields.Selection([('father_is_legal_guardian', 'Father is the legal guardian'), ('mother_is_legal_guardian', 'Mother is the legal guardian'), ('other', 'Other')], related='family_id.legal_guardian', string='Legal Guardian')
    guardian_full_name = fields.Char('Guardian Full Name', related='family_id.guardian_full_name', tracking=True)
    guardian_full_name_arabic = fields.Char('Guardian Full Name Arabic', related='family_id.guardian_full_name_arabic')
    guardian_national_id = fields.Char('National ID', related='family_id.guardian_national_id', tracking=True)
    relation_to_child = fields.Char('Relation to The Child', related='family_id.relation_to_child')
    guardian_nationality = fields.Many2one('res.country', related='family_id.guardian_nationality', string='Nationality')
    guardian_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], related='family_id.guardian_marital_status', string='Marital Status')
    guardian_degree_education = fields.Char('Education', related='family_id.guardian_degree_education')
    guardian_employment = fields.Char('Employment', related='family_id.guardian_employment')
    guardian_employeer_location = fields.Char('Employment Location', related='family_id.guardian_employeer_location')
    guardian_landline_number = fields.Char('Home Phone', related='family_id.guardian_landline_number')
    guardian_land_line_no = fields.Char('Work Phone', related='family_id.guardian_land_line_no')
    guardian_mobile_no = fields.Char('Mobile Number', tracking=True)
    guardian_email = fields.Char(string = 'Email', related='family_id.guardian_email')
    student_class_ids = fields.One2many('student.class', 'student_id', string='Student Class')
    student_courses_ids = fields.One2many('student.courses', 'student_id', string='Student Courses')
    #moodle
    md_parent_username = fields.Char('Parent User Name')
    md_password = fields.Char('Password')
    md_username = fields.Char('User Name')
    mooddle_id = fields.Char('Moodle ID', tracking=True)
    moodle_status = fields.Selection([('active', 'Active'), ('in_active', 'In Active'), ('deleted', 'Deleted')], tracking=True, string='Moodle Status')
    reason = fields.Selection([('Fee_defaulter','Fee Defaulter'),('other','Other')],'Reason',default='Fee_defaulter')
    due_amount = fields.Float(compute='_due_month', string='Due Amount')
    fee_balance = fields.Float(compute='student_fee_balance', string='Fee Balance')
    due_month = fields.Char(compute='_due_month', string='Due Month')
  
    def student_fee_balance(self):
        """
        Call this central method whenever you need to findout total outstanding dues not paid 
        by student, may be this method is more enhanced in future...
        
        """
        for student in self:
            _sql = """SELECT  COALESCE(sum(total_amount),'0')  FROM student_fee
                      WHERE student_id = """+str(student.id)+ """ AND status = 'unpaid' """  
            self.env.cr.execute(_sql)
            amount = self.env.cr.fetchone()[0]
            self.fee_balance = amount
        
    def _due_month(self):
        today = fields.Date.today()
        std_fee = self.env['student.fee'].search([('student_id','=',self.id),('status','=','unpaid'),('due_date','>',today)])
        smaller_duedate = '00-00-0000'
        smaller_amount = 0.0
        if std_fee:
            smaller_duedate = std_fee[-1].due_date 
            
            smaller_amount = std_fee[-1].applied_fee
            if smaller_duedate:
                smaller_duedate =str(datetime.strptime(str(smaller_duedate), '%Y-%m-%d').strftime('%d-%b-%Y'))
        
        self.due_month = smaller_duedate
        self.due_amount = smaller_amount
        return
    
        
    def action_dues_student_fee(self):
        
        today = datetime.now()
        std_fee = self.env['student.fee'].search([('student_id','=',self.env.context.get('std_id')),('status','=','unpaid'),('due_date','>',today)])
        if std_fee:
            std_fee =std_fee[0]
        return {
            'name':'Student Fee',
            'view_type': 'form',
            'view_mode': 'tree',
            'view_id': self.env.ref('sms_core.sms_core_fee_student_fee_tree').id,
            'res_model': 'student.fee',
            'type': 'ir.actions.act_window',
            'target': 'new',
             'domain': "[('id', '=', %s)]" % std_fee.id,
            }
    def write(self, vals):
        re = super(AcademicStudent, self).write(vals)
        res = self.env['academic.student'].browse(self.id)
        if 'full_name' in vals:
            full_name = res.full_name.split()
            first_name = full_name[0]
            last_name =' '
            if len(full_name) >1:
                 last_name = full_name[1]
            print("-----------full name------------",last_name,first_name)
            
            try:
                parameters = '&users[0][id]=' + str(res.mooddle_id) + '&users[0][username]=' + str(res.md_username) + '&users[0][firstname]=' + str(first_name)+ '&users[0][lastname]=' + str(last_name)+ '&users[0][password]=' + str(res.md_password)
                moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_user_update_users&moodlewsrestformat=json'
                head_params = {'wsfunction':'core_user_update_users', 'moodlewsrestformat':'json'}
                response = requests.get(moodle_url, params=head_params)
                response = response.json()
                print("User update on LMS response",response)
            except:
                raise UserError(_('Record not updated on lms contact your system administrator'))
        return res


class StudentClass(models.Model):
    _name = "student.class"
    _description = "student.class"
    
    def unlink(self):
        if self.status != 'draft':
            raise UserError(_('Record can only be deleted in Draft State.'))
        else:
            rec = super(StudentClass, self).unlink()    
        return rec
    
    student_id = fields.Many2one('academic.student', string='Student')
    class_id = fields.Many2one('school.class', string='Class')
    class_section_id = fields.Many2one('class.section', string='Section', tracking=True)
    std_course_ids = fields.One2many('student.courses', 'std_class_id', string='Courses')
    status = fields.Selection([('draft', 'Draft'), ('active', 'Active'), ('closed', 'Closed'), ('withdrawn', 'Withdrawn')], string='Status')
    
    @api.model
    def create(self, vals):
        class_obj = super(StudentClass, self).create(vals)
        try:
            parameters = '&members[0][cohorttype][type]=id'+\
                         '&members[0][cohorttype][value]='+str(class_obj.class_section_id.mooddle_id)+\
                         '&members[0][usertype][type]=id'+\
                         '&members[0][usertype][value]='+str(class_obj.student_id.mooddle_id)
                
            moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246' + parameters + '&wsfunction=core_cohort_add_cohort_members&moodlewsrestformat=json'
            head_params = {'wsfunction':'core_cohort_add_cohort_members', 'moodlewsrestformat':'json'}
            response = requests.get(moodle_url, params=head_params)
            response = response.json()
        except:
            raise UserError(_('Record not added on lms contact your system administrator'))
            
        print("this is object ----> ", class_obj)
        course_obj = self.env['class.course'].search([('class_id', '=', class_obj.class_id.id), ('active', '=', True)])
        print("Course object ----> ", course_obj)
        for f in course_obj:
            print("inside for loop ----> ", f)
            self.env['student.courses'].create({
                    'student_id': class_obj.student_id.id,
                    'class_id': class_obj.class_id.id,
                    'class_course_id':f.id,
                    'std_class_id': class_obj.id,
                    'course_status':'active',
                    })
        return class_obj
    
class StudentCourses(models.Model):
    _name = "student.courses"
    _description = "student.courses"
    
    def unlink(self):
        if self.course_status != 'draft':
            raise UserError(_('Record can only be deleted in Draft State.'))
        else:
            rec = super(StudentCourses, self).unlink()    
        return rec
    
    
    student_id = fields.Many2one('academic.student', string='Student')
    class_id = fields.Many2one('school.class', string='Class')
    class_course_id = fields.Many2one('class.course', string='Class Course')
    std_class_id = fields.Many2one('student.class', string='Student Class')
    course_status = fields.Selection([('draft', 'Draft'), ('active', 'Active'), ('closed', 'Closed'), ('withdrawn', 'Withdrawn')], string='Status')
    
    @api.model
    def create(self, vals):
        std_cur_obj = super(StudentCourses, self).create(vals)
        
#         if not std_cur_obj.student_id.mooddle_id or std_cur_obj.class_course_id.mooddle_id:
#             raise UserError(_('%s') % ("Empty Parameter list"))
#         print("student_id.mooddle_id....",std_cur_obj.student_id.mooddle_id)
#         print("" ,std_cur_obj.class_course_id.mooddle_id)
#         
#         course_moodle_id = std_cur_obj.class_course_id.mooddle_id
#         user_moodle_id = std_cur_obj.student_id.mooddle_id
#         if not course_moodle_id:
#             raise UserError(_('The Course '+str(std_cur_obj.class_course_id.name)+' is not available on Moodle. Synch the course before proceeding'))
#         
#         if not user_moodle_id:
#             raise UserError(_('The User '+str(std_cur_obj.student_id.full_name)+' is not available on Moodle. Synch the course before proceeding'))
#         parameters= '&enrolments[0][roleid]=5&enrolments[0][userid]='+str(int(user_moodle_id))+'&enrolments[0][courseid]='+str(int(course_moodle_id))
#         print("print before ",parameters)
#         moodle_url = 'http://35.192.148.38/webservice/rest/server.php?wstoken=ff5b4be8d6383ff175a5522805583246'+parameters+'&wsfunction=enrol_manual_enrol_users&moodlewsrestformat=json'
#         head_params = {'wsfunction':'enrol_manual_enrol_users', 'moodlewsrestformat':'json'}
#         response = requests.get(moodle_url, params=head_params)
#         response = response.json()
#         print("response--------",response)
# #         if response['errorcode']:
#             raise UserError(_('%s') % (response['errorcode']))
#         print("******course response std creation response",response)
        return std_cur_obj
    
    
class StudentParentGuardianInfo(models.Model):
    _name = 'student.parent.guardian.info'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'student.parent.guardian.info'
    
    def _set_name(self):
        print("student parent g------------",self)
        for f in self:
            if not f.father_is_absent:
                f.head_person = 'father'
                f.name = f.father_full_name
            elif not f.mother_is_absent:
                f.head_person = 'mother'
                f.name = f.mother_full_name
            else:
                f.head_person = 'guardian'
                f.name = f.guardian_full_name
        return
    
    name = fields.Char(compute='_set_name', string='Name')
    head_person = fields.Selection([('father', 'Father is Contact Head'), ('mother', 'Mother is Contact Head'), ('guardian', 'Guardian is Contact Head')], string='Head Person')
    student_ids = fields.One2many('academic.student','family_id', string='Childs')
    # Fields (Father) 
    father_full_name = fields.Char('Father Full Name', tracking=True)
    father_full_name_arabic = fields.Char('Father Full Name Arabic')
    father_national_id = fields.Char('National ID', tracking=True)
    father_nationality = fields.Many2one('res.country', string='Nationality')
    father_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], string='Marital Status')
    father_degree_education = fields.Char('Education')
    father_employment = fields.Char('Employment')
    father_employer_location = fields.Char('Employment Location')
    father_landline_number = fields.Char('Home Phone')
    father_land_line_no = fields.Char('Work Phone')
    father_mobile_no = fields.Char('Mobile Number', tracking=True)
    father_email = fields.Char(string='Email')
    father_is_absent = fields.Boolean('Father is Absent')
    
    # Fields(Mother)
    mother_full_name = fields.Char('Mother Full Name', tracking=True)
    mother_full_name_arabic = fields.Char('Mother Full Name Arabic')
    mother_national_id = fields.Char('National ID', tracking=True)
    mother_nationality = fields.Many2one('res.country', string='Nationality')
    mother_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], string='Marital Status')
    mother_degree_education = fields.Char('Education')
    mother_employment = fields.Char('Employment')
    mother_employer_location = fields.Char('Employment Location')
    mother_landline_number = fields.Char('Home Phone')
    mother_land_line_no = fields.Char('Work Phone')
    mother_mobile_no = fields.Char('Mobile Number', tracking=True)
    mother_email = fields.Char(string='Email')
    mother_is_absent = fields.Boolean('Mother is Absent')
    
    # Guardian Fields:
    legal_guardian = fields.Selection([('father_is_legal_guardian', 'Father is the legal guardian'), ('mother_is_legal_guardian', 'Mother is the legal guardian'), ('other', 'Other')], string='Legal Guardian')
    guardian_full_name = fields.Char('Guardian Full Name', tracking=True)
    guardian_full_name_arabic = fields.Char('Guardian Full Name Arabic')
    guardian_national_id = fields.Char('National ID', tracking=True)
    relation_to_child = fields.Char('Relation to The Child')
    guardian_nationality = fields.Many2one('res.country', string='Nationality')
    guardian_marital_status = fields.Selection([('single', 'Single'), ('married', 'Married'), ('divorced', 'Divorced'), ('widow', 'Widow/widower')], string='Marital Status')
    guardian_degree_education = fields.Char('Education')
    guardian_employment = fields.Char('Employment')
    guardian_employeer_location = fields.Char('Employment Location')
    guardian_landline_number = fields.Char('Home Phone')
    guardian_land_line_no = fields.Char('Work Phone')
    guardian_mobile_no = fields.Char('Mobile Number', tracking=True)
    guardian_email = fields.Char(string='Email')

    
      
    
