# -*- coding: utf-8 -*-

from . import report_admission_list
from . import std_admission_biodata_report
from . import students_information_report
from . import parents_guardian_info_report
from . import report_fee_collection_dues
from . import report_student_fee
