from odoo import models, fields, api


class Employee(models.Model):
    _inherit = 'hr.employee'

    appraisal_enable = fields.Boolean('Appraisal Enabled?', related='department_id.appraisal_enable')

    def write(self, vals):
        group_id = self.env.ref('sky_hr_appraisal.group_appraisal_user')
        existing_user_id = self.parent_id and self.parent_id.user_id
        existing_emp = self.parent_id
        res = super(Employee, self).write(vals)
        for rec in self:
            if vals.get('parent_id'):
                emp = self.browse(vals.get('parent_id'))
                if emp and rec.child_ids:
                    emp.user_id.write({'groups_id': [(4, group_id.id)]})
            else:
                if not existing_emp.child_ids:
                    existing_user_id.write({'groups_id': [(3, group_id.id)]})

        return res
