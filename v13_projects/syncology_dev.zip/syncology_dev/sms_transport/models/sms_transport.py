# -*- coding: utf-8 -*-
from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError
from odoo.osv import expression
import requests, json
from datetime import datetime, timedelta
from datetime import datetime
from datetime import date
from _ast import Try
from email.policy import default
from odoo.addons.test_convert.tests.test_env import field
import string

class RegisterStudentTransport(models.Model):
    
    _name = 'register.student.transport'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'register.student.transport'
    
    def set_regno(self):
        sql = """select COALESCE(max(id),'0') from register_student_transport where state = 'registered'"""
        self.env.cr.execute(sql)
        idd = self.env.cr.fetchone()[0]
        idd = int(idd)+1
        self.name = "TR"+str(idd).zfill(4)+str(self.student_id.full_name or '--')
        return
    
    def confirm_registration(self):
        self.state = 'registered'
        self.date_registered = fields.Date.today()
        self.registered_by = self._uid
        self.set_regno()
        return
    
    def withdraw_from_transport(self):
        self.state = 'withdrawal'
        self.date_registered = fields.Date.today()
        self.withdrawn_by = self._uid
        return

    @api.onchange('student_id')
    def onchange_student_domain(self):
        std_list =[]
        std_ids = self.search([('state','=',['draft','registered'])]) 
        for s in std_ids:
            std_list.append(s.student_id.id)
        return {'domain': {'student_id': [('id', 'not in',std_list),('state','=','admitted')]}}
    
    def unlink(self):
        if self.state != 'draft':
            raise UserError(('Record can only be deleted in Draft State. Use the option of withdraw instead.'))
        else:
            rec = super(RegisterStudentTransport, self).unlink()    
        return rec
    
    name = fields.Char(string = 'Reg No')
    student_id = fields.Many2one('academic.student', domain="[('state','=','admitted')]", string="Student", tracking=True)
    class_grade = fields.Many2one('school.class', string = 'Grade', related='student_id.class_id')
    bus_id = fields.Many2one('fleet.vehicle',string ='Bus', tracking=True)
    count_in = fields.Integer(string = 'Count')
    count_out = fields.Integer(string = 'Count out')
    primary_handover = fields.Char('Primary Handover',related='student_id.family_id.name')
    secondary_handover = fields.Char('Secondary Handover')
    family_condition = fields.Selection([('stable', 'Stable'),('seperated', 'Seperated'),('sensitively', 'Sensitively')],default = 'stable',string = 'Family Condition')
    city = fields.Many2one('sms.cities', tracking=True)
    father_mobile = fields.Char(related='student_id.father_landline_number',string = 'Father Phone')
    mother_mobile = fields.Char(related='student_id.mother_landline_number',string = 'Mother Phone')
    guardian_mobile = fields.Char(related='student_id.guardian_landline_number',string = 'Guardian Phone')
    main_street = fields.Char('Main Street', tracking=True)
    bystreet = fields.Char('By Street', tracking=True)
    more_details = fields.Text('More Details')
    registered_by = fields.Many2one('res.users',string="Registered By")
    date_registered = fields.Date('Date Registered') 
    withdrawn_by = fields.Many2one('res.users',string="Withdrawn By")
    date_withdrawn = fields.Date('Date Withdrawn') 
    state = fields.Selection([('draft', 'Draft'),('registered', 'Registered'),('withdrawal', 'Withdrawal')],default = 'draft',string = 'State', tracking=True)
    email = fields.Char(related='student_id.guardian_email',string = 'Email')

class TransportRouteStop(models.Model):
    
    _name = 'transport.route.stop'
    _description = 'transport.route.stop'
    
    def unlink(self):
        raise UserError(('Deletion not allowed'))
    
    
    name = fields.Char('Route Stop')
    active = fields.Boolean('Active',default = True)
    rout_ids = fields.Many2many('transport.route',ondelete='restrict')
    buses_ids = fields.Many2many('fleet.vehicle',ondelete='restrict')

class TransportRoute (models.Model):
    
    _name = 'transport.route'
    _description = 'transport.route'
    
    def unlink(self):
        raise UserError(('Deletion not allowed'))
    
    name = fields.Char('Route')
    start_point = fields.Char('Start Point',tracking= True)
    end_point = fields.Char('End Point',tracking= True)
    stops_ids = fields.Many2many('transport.route.stop', string='Stop')
    busses_ids = fields.Many2many('fleet.vehicle')
    active = fields.Boolean('Active',default = True)

class VehicleModel(models.Model):
    _name = 'fleet.vehicle.model'
    _inherit = 'fleet.vehicle.model'
    _order = 'name asc'
    
    

    @api.depends('name', 'brand_id')
    def name_get(self):
        """Acutal name of the model is changed to make it simple, name_get() is overriden from orignal method """
        res = []
        for record in self:
            name = record.name
            res.append((record.id, name))
        return res
    
class TransportBus(models.Model):
    
    _name = 'fleet.vehicle'
    _inherit = 'fleet.vehicle'
    
    
    @api.depends('model_id.name', 'license_plate')
    def _compute_vehicle_name(self):
        for record in self:
#             record.name = 'Not Set'
            record.name = str(record.model_id.name) or '--' + '/' + str(record.license_plate or ('--'))
    
    def get_bus_student_list(self,state,bus_id):
        lst = self.env['register.student.transport'].search([('state','=',state),('bus_id','=',bus_id)])
        return lst

    def vehicle_stdent_con(self):
#         self.ensure_one()
       # @sir shihid plz see this issue  i  have ensure one but still give multiple record
        for f in self:
            std_lst = self.get_bus_student_list('registered',f.id)
        self.veh_std_count = len(std_lst)
        return
        
    def return_action_to_open_student(self):
        return {
            'name':'Student',
            'view_type': 'form',
            'view_mode': 'tree',
            'view_id': self.env.ref('sms_core.sms_core_academic_student_tree').id,
            'res_model': 'academic.student',
            'type': 'ir.actions.act_window',
            'target': 'new',
             'domain': [('id', 'in', [x.student_id.id for x in self.get_bus_student_list('registered',self.id)])],
            }
        
    def unlink(self):
        raise UserError(('Deletion is not allowed'))    
    
    bus_number = fields.Integer(string='Bus Number')
    vehical_driver_history_id = fields.Char('vehical.driver.history')
    state = fields.Selection([('in_operation', 'Operational'),('maintenance', 'Down For Maintenance'),('permanently_down', 'Removed')], default = 'in_operation',string = 'State')
    veh_std_count = fields.Char(compute='vehicle_stdent_con',string = 'Strength')
    period = fields.Selection([('first', 'First'),('second', 'Second')], default="first", string='Period')
    routes_ids = fields.Many2many('transport.route','vehicle_route_rel','vehicle_id','route_id', string='Routes')
    vehicle_driver_id = fields.Many2one('hr.employee', string='Driver', domain="[('job_id.name','=','Driver')]")
    driver_contact_no = fields.Char('Contact No', related='vehicle_driver_id.mobile_phone')
    supervisor_id = fields.Many2one('hr.employee', string='Supervisor', domain="[('job_id.name','=','Supervisor')]")
    supervisor_contact_no = fields.Char('Contact No', related='supervisor_id.mobile_phone')
    route = fields.Many2one('transport.route', string='Route', domain="[('active','=',True)]")
    bus_description = fields.Char('Description')
    name = fields.Char(string='Vehicle',compute='_compute_vehicle_name')

class TransportComplaintManagement(models.Model):
    _name = 'transport.complaint.management'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'transport.complaint.management'
    
    def set_copno(self):
#         print("set complaint management system")
#         sql = """select COALESCE(max(id),'0') from transport_complaint_management where state = 'resolved_by'"""
#         self.env.cr.execute(sql)
#         idd = self.env.cr.fetchone()[0]
#         idd = int(idd)+1
#         print("this is complaint no",idd)
        for record in self:
            record.complaint_no = "CMP"+str(record.id).zfill(4)+str(record.student_name.full_name or '--')
        return
    def resolved_complaint(self):
        self.resolved_by = self._uid
        self.date_resolved = datetime.now()
        self.set_copno()
        self.state = 'resolved'
        
    def cancel_complaint(self):
        cancel_date = datetime.now()
        cancel_by = self._uid
        self.state = 'closed'
        
    def _compute_complaint_name(self):
        for record in self:
            record.name = 'CMP'+str(record.id).zfill(4)
        return
    
    name = fields.Char(string = 'No',compute='_compute_complaint_name')
    complaint_no =fields.Char(string = 'Complaint No',compute='set_copno')
    escalated = fields.Boolean('Escalated',default = True)
    bus_number = fields.Many2one('fleet.vehicle', string='Bus',domain=[('active', '=',True)],tracking=True)
    period =  fields.Selection([('first','First'),('second', 'Second')], default='first',string='Period')
    driver_name = fields.Many2one('hr.employee', string='Driver', related='bus_number.vehicle_driver_id',domain=[('transport_speciliztion', '=','is_driver')])
    driver_phone = fields.Char(related='driver_name.mobile_phone',string ='Mobile Number ')
    supervisor_name = fields.Many2one('hr.employee', string='Supervisor', related='bus_number.supervisor_id',domain=[('transport_speciliztion','=','is_supervisor')])
    supervisor_phone = fields.Char(related='supervisor_name.mobile_phone',string ='Mobile Number ')
    complain_from =  fields.Selection([('student','Student'),('driver', 'Driver'),('supervisor', 'Supervisor')], default='student',string='Complain From',tracking=True)
    complain_against =  fields.Selection([('student','Student'),('driver', 'Driver'),('supervisor', 'Supervisor')],default='driver', string='Complain Against',tracking=True)
    student_name = fields.Many2one('academic.student', string='Student',tracking=True)
    date = fields.Date(string ='Date of Incident')
    severity =  fields.Selection([('low','Low'),('medium', 'Medium'),('high', 'High'),('major', 'Major')],default='low', string = 'Severity',tracking=True)
    complain=fields.Text(string = 'Complain')
    state = fields.Selection([('received', 'Reported'),('resolved', 'Resolved'),('closed', 'Closed')],default = 'received',string = 'State',tracking=True)
   
    resolved_by = fields.Many2one('hr.employee', string='Resolved by')
    date_resolved = fields.Date(string ='Resolved Date')
    cancel_by = fields.Many2one('hr.employee', string='Cancel by')
    cancel_date = fields.Date(string ='Cancel Date')
    
    
    def unlink(self):
        raise UserError(('Deletion not allowed'))
    
class TransportScheduling(models.Model):
    _name = 'transport.scheduling'
    _description = 'transport.scheduling'
    
    def _compute_schedule_name(self):
        for record in self:
            record.name = 'SCH'+str(record.id).zfill(4)+"-"+str(record.bus_id.license_plate)
        return
    
    def compute_scheduling_status(self):
        for ts in self:
            today = datetime.now()
            if ts.schedule_date == today.date():
                ts.state = 'active'
            if ts.schedule_date > today.date():
                ts.state = 'draft'
            if ts.schedule_date < today.date():
                ts.state = 'closed'
    
    
    name = fields.Char(string = 'No',compute='_compute_schedule_name')
    schedule_date = fields.Date('Date')
    bus_id = fields.Many2one('fleet.vehicle', string='Bus',domain=[('active', '=',True)])
    driver_id = fields.Many2one('hr.employee', string='Driver', related='bus_id.vehicle_driver_id',domain=[('transport_speciliztion', '=','is_driver')])
    supervisor_id = fields.Many2one('hr.employee', string='Supervisor', related='bus_id.supervisor_id',domain=[('transport_speciliztion','=','is_supervisor')])
    routes_ids = fields.Many2many('transport.route','schedul_route_rel','schedul_id','route_id', string='Routes', related='bus_id.routes_ids')    
    students_ids = fields.Many2many('register.student.transport')
    state = fields.Selection([('draft', 'Draft'),('active', 'Active'),('closed', 'Closed'),('cancel', 'Cancel')], compute="compute_scheduling_status",string = 'State', tracking=True)
    
    
    
    @api.model
    def create(self, vals):
        today = fields.Date.today()
        if str(vals['schedule_date']) < str(today):
            raise UserError(('Schedule are not allowed in previous date'))
        exist_rec = self.search([('schedule_date','=',vals['schedule_date']),('bus_id','=',vals['bus_id'])]) 
        if exist_rec:
            raise UserError(('Record Already Exist'))
        class_obj = super(TransportScheduling, self).create(vals)
        return class_obj
    
    
    @api.onchange('bus_id')
    def onchange_fill_student(self):
        if self.bus_id:
            std_ids = self.env['register.student.transport'].search([('bus_id','=',self.bus_id.id)])
            self.students_ids = std_ids.ids
        
    def unlink(self):
        if self.state != 'draft':
            raise UserError(('Record can only be deleted in Draft State.'))
        else:
            rec = super(TransportScheduling, self).unlink()    
        return rec
    
class HrEmployee (models.Model):
    
    _name = 'hr.employee'
    _inherit = 'hr.employee'
    
    def unlink(self):
        raise UserError(('Deletion not allowed'))
    
    buses_ids = fields.One2many('fleet.vehicle','vehicle_driver_id', string='Vehicles')
    transport_speciliztion = fields.Selection([('is_driver', 'Is Drive'),('is_supervisor', 'Is Supervisor')], default='is_driver',string = 'Specilization')
    
class SmsCities(models.Model):
    _name = 'sms.cities'
    _description = 'sms.cities'
    
    name = fields.Char('Name', required=True)