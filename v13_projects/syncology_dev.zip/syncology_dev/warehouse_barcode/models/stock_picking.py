##########################################################################################
#
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#    Copyright (C) 2020 Skyscend Business Solutions Pvt. Ltd. (http://www.skyscendbs.com)
#
##########################################################################################
from odoo import models, fields, api


class Picking(models.Model):
    _name = "stock.picking"
    _inherit = ['stock.picking', 'barcodes.barcode_events_mixin']

    def on_barcode_scanned(self, barcode):
        """
        This method is used to process the scanned barcode.
        It will create a new line with the product matching the barcode.
        If the line is already existing, it will update the quantity for that product.
        ------------------------------------------------------------------------------
        @param barcode: The scanned barcode
        """
        prod_obj = self.env['product.product']
        if self.picking_type_code == "incoming":
            for order in self:
                product = prod_obj.search([('barcode', '=', barcode)], limit=1)
                stock_line = order.move_ids_without_package.filtered(lambda r: r.product_id.id == product.id)
                if len(stock_line) > 0:
                    stock_line = stock_line[0]
                    stock_line.quantity_done = stock_line.quantity_done + 1
                else:
                    stock_line_vals = {
                        'product_id': product.id,
                        'description_picking': product.name,
                        'product_uom': product.uom_po_id.id,
                        'quantity_done': 1,
                    }
                    order.move_ids_without_package = [(0, 0, stock_line_vals)]
                    order.move_ids_without_package.name = product.name
                    order.move_ids_without_package.location_id = self.location_id.id
                    order.move_ids_without_package.location_dest_id = self.location_dest_id.id
        elif self.picking_type_code == "outgoing":
            for order in self:
                product = prod_obj.search([('barcode', '=', barcode)], limit=1)
                stock_line = order.move_line_ids_without_package.filtered(lambda r: r.product_id.id == product.id)
                if len(stock_line) > 0:
                    stock_line = stock_line[0]
                    stock_line.qty_done = stock_line.qty_done + 1
                else:
                    stock_line_vals = {
                        'product_id': product.id,
                        'product_uom_id': product.uom_po_id.id,
                        'location_id': self.location_id.id,
                        'location_dest_id': self.location_dest_id.id,
                        'qty_done': 1,
                    }
                    order.move_line_ids_without_package = [(0, 0, stock_line_vals)]
        else:
            for order in self:
                product = prod_obj.search([('barcode', '=', barcode)], limit=1)
                stock_line = order.move_line_ids_without_package.filtered(lambda r: r.product_id.id == product.id)
                if len(stock_line) > 0:
                    stock_line = stock_line[0]
                    stock_line.qty_done = stock_line.qty_done + 1
                else:
                    stock_line_vals = {
                        'product_id': product.id,
                        'product_uom_id': product.uom_po_id.id,
                        'location_id': self.location_id.id,
                        'location_dest_id': self.location_dest_id.id,
                        'qty_done': 1,
                    }
                    order.move_line_ids_without_package = [(0, 0, stock_line_vals)]
