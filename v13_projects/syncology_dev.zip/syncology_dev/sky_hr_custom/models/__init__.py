from . import hr_qualification
from . import hr_employee
from . import hr_contract
from . import hr_employee_status
from . import hr_department
from . import res_state