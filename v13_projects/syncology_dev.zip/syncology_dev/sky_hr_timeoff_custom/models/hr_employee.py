# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#
##############################################################################
from odoo import models, fields, api, _


class Employee(models.Model):
    _inherit = 'hr.employee'
    _description = 'Employee'

    # Leave & Vacation Balance
    leave_balance = fields.Float('Leave Balance', compute='_cal_leave_balance')
    vacation_balance = fields.Integer('Vacation Balance', compute='_cal_leave_balance')
    total_leave = fields.Float(compute='_cal_leave_balance', string='Leaves')
    total_vacation = fields.Integer(compute='_cal_leave_balance', string='Vacations')
    total_alloc_leave = fields.Float('Leave Allocations', compute='_cal_leave_balance')
    total_alloc_vacation = fields.Integer('Vacation Allocations', compute='_cal_leave_balance')
    leave_monthly_allowance = fields.Float('Leave Monthly Allowance', compute='_cal_leave_balance')
    vacation_monthly_allowance = fields.Integer('Vacation Monthly Allowance',
                                                related='department_id.vacation_monthly_allowance')

    def _load_records_create(self, values):
        return super(Employee,self.with_context(mail_notify_force_send=False))._load_records_create(values)

    @api.model_create_multi
    def create(self, vals_lst):
        """
        Overridden create() method to assign leaves and vacations to employee
        ---------------------------------------------------------------------
        :@param self: object pointer
        :param vals_lst: A list of dictionary containing fields and values
        :return: A newly created recordset.
        """
        res = super(Employee, self).create(vals_lst)
        department_obj = self.env['hr.department']
        for emp in res:
            department_obj.with_context(create_allocation= emp).auto_leave_allocation()

        return res

    def _cal_leave_balance(self):
        leave_alloc_obj = self.env['hr.leave.allocation']
        leave_request_obj = self.env['hr.leave']
        for employee in self:
            leave_allocation = leave_alloc_obj.search([('employee_id', '=', employee.id),
                                                       ('state', 'in', ('validate', 'validate1')),
                                                       ('leave_type', '=', 'leave')])
            leave_allocation_days = sum(leave_allocation.mapped('number_of_hours_display'))
            employee.total_alloc_leave = leave_allocation_days
            leaves = leave_request_obj.search([('employee_id', '=', employee.id),
                                               ('state', 'in', ('validate', 'validate1')),
                                               ('leave_type', '=', 'leave'),
                                               ('holiday_status_id.unpaid', '=', False)])
            leave_hours = sum(leaves.mapped('end_time')) - sum(leaves.mapped('start_time'))
            employee.total_leave = leave_hours
            employee.leave_balance = leave_allocation_days - leave_hours
            employee.leave_monthly_allowance = employee.department_id.leave_monthly_allowance - leave_hours

            vacation_allocation = leave_alloc_obj.search([('employee_id', '=', employee.id),
                                                          ('state', 'in', ('validate', 'validate1')),
                                                          ('leave_type', '=', 'vacation')])
            vacation_allocation_days = sum(vacation_allocation.mapped('number_of_days'))
            employee.total_alloc_vacation = vacation_allocation_days
            vacations = leave_request_obj.search([('employee_id', '=', employee.id),
                                                  ('state', '=', 'validate'),
                                                  ('leave_type', '=', 'vacation'),
                                                  ('holiday_status_id.unpaid', '=', False)])
            vacation_days = sum(vacations.mapped('number_of_days'))
            employee.total_vacation = vacation_days
            employee.vacation_balance = vacation_allocation_days - vacation_days

    def update_leave_vacation_balance(self):
        return {
            'name': _("Update Leave/Vacation Balance"),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'update.leave.vacation.balance',
            'target': 'new',
            'context': {'default_current_leave_balance': self.leave_balance,
                        'default_current_vacation_balance': self.vacation_balance}
        }
