from odoo import models, fields, api, _


class HrLeaveType(models.Model):
    _inherit = 'hr.leave.type'
    _description = 'Hr Leave Type'

    leave_type = fields.Selection([('vacation', 'Vacation'),
                                   ('leave', 'Leave')], 'Leave Type')
    unpaid = fields.Boolean("Unpaid")
    request_unit = fields.Selection([
        ('day', 'Day'), ('half_day', 'Half Day'), ('hour', 'Hours')],
        default='hour', string='Take Time Off in', required=True)
