# -*- encoding: utf-8 -*-
##############################################################################
#
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#    Copyright (C) 2019 Skyscend Business Solutions (http://www.skyscendbs.com)
#
##############################################################################
from odoo import models, fields, api, _


class UpdateLeaveVacationBalance(models.TransientModel):
    _name = 'update.leave.vacation.balance'
    _description = 'Update Leave/Vacation Balance Wizard'

    update_type = fields.Selection([('leave', 'Leave'),
                                    ('vacation', 'Vacation'),
                                    ('both', 'Both')], default='leave')
    current_leave_balance = fields.Float('Current Leave Balance')
    new_leave_balance = fields.Float('New Leave Balance')
    current_vacation_balance = fields.Float('Current Vacation Balance')
    new_vacation_balance = fields.Float('New Vacation Balance')

    def action_confirm(self):
        leave_alloc_obj = self.env['hr.leave.allocation']
        current_id = self.env.context.get('active_id')
        employee = self.env['hr.employee'].browse(current_id)
        leave_balance = self.new_leave_balance - employee.leave_balance
        vacation_balance = self.new_vacation_balance - employee.vacation_balance

        if self.update_type in ('leave', 'both'):
            leave_alloc_vals = {
                'name': 'Monthly Leave Allocation for ' + employee.name,
                'employee_id': employee.id,
                'holiday_type': 'employee',
                'allocation_type': 'regular',
                'leave_type': 'leave',
                'number_of_days': leave_balance
            }
            leave_alloc = leave_alloc_obj.create(leave_alloc_vals)
            leave_alloc.action_approve()
        if self.update_type in ('vacation', 'both'):
            vacation_alloc_vals = {
                'name': 'Monthly Leave Allocation for ' + employee.name,
                'employee_id': employee.id,
                'holiday_type': 'employee',
                'allocation_type': 'regular',
                'leave_type': 'vacation',
                'number_of_days': vacation_balance
            }
            vacation_alloc = leave_alloc_obj.create(vacation_alloc_vals)
            vacation_alloc.action_approve()
